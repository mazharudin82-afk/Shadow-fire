# Shadow Fire (web / Three.js) - original mobile battle royale

No Unity, no license. Built with Three.js + Vite, packaged to an Android APK by GitHub Actions (Capacitor).

## Features
- 50 actors (solo or squad of 4 with bot mates), ~10 min match, parachute drop, shrinking zone (7 phases, damage ramp), airdrops (every phase), loot tiers
- TPS over-right-shoulder camera, ADS, hip-fire spread cone, per-gun recoil patterns (climb + wander) with recovery, attachments (muzzle/grip/mag/scope)
- Drag-to-aim: right thumb = look, FIRE button left. Capsule aim assist (off/low/med/high); fast upward drag snaps aim from body to head (80 ms lerp); limbs never auto-targeted
- Sensitivity model: hip / ADS / scoped / gyro multipliers, per-gun scale, exponent curve, settings page, auto-fire toggle, HUD scale, fire-button side
- Hitboxes head/chest/limbs with multipliers, armor + helmet tiers, backpack tiers, bandage/medkit, knockdown + revive (squad), Frostwall cover (destructible), 3 original abilities, pets
- Island "Emberveil" (2x2 km playable): 6 POIs, drivable jeeps, destructible crates, minimap + compass, kill feed
- AI bots: loot, fight, avoid zone, revive mates

## Tests (run in CI, also locally with `npm install && npm test`)
- tests/sim.mjs: full 50-actor match headless
- tests/ui-smoke.mjs: UI + input wiring with a fake DOM

## Not included yet
Online multiplayer (needs a server), boats, character art/animation, real audio assets, 8x8 km map (this island is 2x2 km for mobile performance).
