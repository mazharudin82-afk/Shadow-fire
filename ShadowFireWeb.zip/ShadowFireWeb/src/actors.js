import * as THREE from 'three';
import { Inventory } from './inv.js';

export const EYE = [1.6, 1.1, 0.4];
const HEAD_Y = [1.6, 1.1, 0.4], CT = [1.45, 1.0, 0.4], CB = [0.95, 0.6, 0.25], LT = [0.9, 0.6, 0.25], AY = [1.2, 0.85, 0.35];
export const SPEED = [4.8, 2.6, 1.2];
const SCALE_Y = [1, 0.68, 0.32];
let nextId = 1;

function makeModel(color, isPlayer) {
  const g = new THREE.Group();
  const body = new THREE.MeshLambertMaterial({ color });
  const skin = new THREE.MeshLambertMaterial({ color: 0xe0b48a });
  const dark = new THREE.MeshLambertMaterial({ color: isPlayer ? 0x1c3c7a : 0x333333 });
  const add = (geo, mat, x, y, z) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); g.add(m); return m; };
  add(new THREE.BoxGeometry(0.46, 0.55, 0.26), body, 0, 1.2, 0);
  add(new THREE.SphereGeometry(0.14, 8, 6), skin, 0, 1.62, 0);
  add(new THREE.BoxGeometry(0.17, 0.8, 0.2), dark, -0.12, 0.4, 0);
  add(new THREE.BoxGeometry(0.17, 0.8, 0.2), dark, 0.12, 0.4, 0);
  add(new THREE.BoxGeometry(0.1, 0.55, 0.12), body, -0.32, 1.2, 0);
  add(new THREE.BoxGeometry(0.1, 0.55, 0.12), body, 0.32, 1.2, 0);
  add(new THREE.BoxGeometry(0.07, 0.1, 0.7), dark, 0.2, 1.2, -0.4); // gun
  return g;
}

export function createActor(G, o) {
  const a = {
    id: nextId++, name: o.name, team: o.team, isPlayer: !!o.isPlayer, x: o.x, y: o.y, z: o.z, vy: 0,
    yaw: o.yaw || 0, pitch: 0, stance: 0, radius: 0.4, height: 1.75, hp: 100, maxHp: 100, shield: 0, armor: 0, helmet: 0,
    downed: false, downedHp: 60, reviveProg: 0, dead: false, air: !!o.air, inv: new Inventory(), guns: [null, null], cur: 0,
    kills: 0, lastHit: -99, healing: null, speedMul: 1, grounded: false, ai: null, aim: null, vehicle: null, ads: false, mesh: null, color: o.color,
  };
  a.mesh = makeModel(o.color, a.isPlayer);
  G.scene.add(a.mesh);
  G.actors.push(a);
  return a;
}
export function syncMesh(a, cx, cz) {
  const m = a.mesh; if (!m) return;
  const far = Math.hypot(a.x - cx, a.z - cz) > 260;
  m.visible = !a.dead && !a.vehicle && !far;
  if (!m.visible) return;
  m.position.set(a.x, a.y, a.z);
  m.rotation.y = a.yaw;
  m.rotation.x = a.downed ? -1.3 : 0;
  m.scale.y = a.downed ? 1 : SCALE_Y[a.stance];
}
export const gunOf = (a) => a.guns[a.cur];
export const eyePos = (a) => ({ x: a.x, y: a.y + EYE[a.stance], z: a.z });
export const rightOf = (a) => ({ x: Math.cos(a.yaw), z: -Math.sin(a.yaw) });

export function keypoints(a) {
  const s = a.stance, y = a.y;
  return { head: { x: a.x, y: y + HEAD_Y[s], z: a.z }, top: { x: a.x, y: y + CT[s], z: a.z }, bot: { x: a.x, y: y + CB[s], z: a.z } };
}
/// analytic hitboxes: head (sphere), chest (capsule), limbs (capsules)
export function hitShapes(a) {
  const s = a.stance, y = a.y, r = rightOf(a), k = keypoints(a), out = [];
  out.push({ a: k.head, b: k.head, r: 0.16, part: 'head' });
  out.push({ a: k.bot, b: k.top, r: 0.24, part: 'chest' });
  for (const sg of [-1, 1]) {
    out.push({ a: { x: a.x + r.x * 0.12 * sg, y: y + 0.05, z: a.z + r.z * 0.12 * sg }, b: { x: a.x + r.x * 0.12 * sg, y: y + LT[s], z: a.z + r.z * 0.12 * sg }, r: 0.13, part: 'limb' });
    out.push({ a: { x: a.x + r.x * 0.32 * sg, y: y + AY[s] - 0.3, z: a.z + r.z * 0.32 * sg }, b: { x: a.x + r.x * 0.32 * sg, y: y + AY[s] + 0.12, z: a.z + r.z * 0.32 * sg }, r: 0.09, part: 'limb' });
  }
  return out;
}
