import { raySeg, clamp, norm3 } from './util.js';
import { keypoints } from './actors.js';
import { S } from './settings.js';

// r = capsule radius (m), bp/hp = body/head pull, thr = upward drag speed (deg/s) that snaps to head, lm = snap speed mul
export const LEVELS = { off: null, low: { r: 0.35, bp: 0.3, hp: 0.6, thr: 220, lm: 1 }, med: { r: 0.5, bp: 0.5, hp: 0.8, thr: 160, lm: 1 }, high: { r: 0.7, bp: 0.75, hp: 0.95, thr: 110, lm: 1.6 } };
export const SNAP_TIME = 0.08;

/// Capsule + drag-threshold aim assist. Never targets limbs: aim point only moves between torso center and head.
export function updateAssist(G, p, o, d, dragUp, dt) {
  const A = p.aim || (p.aim = { target: null, head: 0, pull: 0, point: null, until: 0, k: null, dist: 0 });
  const lv = LEVELS[S.assist]; A.target = null; A.pull = 0;
  if (!lv || p.dead || p.downed || p.air || p.vehicle) { A.head = Math.max(0, A.head - dt / SNAP_TIME); return; }
  let best = 1e9;
  for (const a of G.actors) {
    if (a === p || a.dead || a.team === p.team || a.air) continue;
    const dx = a.x - o.x, dz = a.z - o.z;
    if (dx * dx + dz * dz > 4900 || dx * d.x + dz * d.z <= 0) continue;
    const k = keypoints(a), r = raySeg(o, d, k.bot, k.top);
    if (r.d < lv.r && r.d < best) { best = r.d; A.target = a; A.k = k; A.dist = r.d; }
  }
  if (A.target && dragUp > lv.thr) A.until = G.time + 0.25;
  const wantHead = !!A.target && G.time < A.until;
  A.head = clamp(A.head + (wantHead ? 1 : -1) * dt / (SNAP_TIME / lv.lm), 0, 1);
  if (!A.target) return;
  const k = A.k, bx = (k.bot.x + k.top.x) / 2, by = (k.bot.y + k.top.y) / 2, bz = (k.bot.z + k.top.z) / 2;
  A.point = { x: bx + (k.head.x - bx) * A.head, y: by + (k.head.y - by) * A.head, z: bz + (k.head.z - bz) * A.head };
  const base = lv.bp * clamp(1.25 - A.dist / lv.r, 0, 1);
  A.pull = base + (lv.hp - base) * A.head;
}
export function redirect(p, o, d) {
  const A = p.aim;
  if (!A || !A.target || A.pull < 0.001 || !A.point) return d;
  const t = norm3({ x: A.point.x - o.x, y: A.point.y - o.y, z: A.point.z - o.z });
  return norm3({ x: d.x + (t.x - d.x) * A.pull, y: d.y + (t.y - d.y) * A.pull, z: d.z + (t.z - d.z) * A.pull });
}
