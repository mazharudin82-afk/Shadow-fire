import { S, save, resetSens } from './settings.js';
import { ABILITIES, PETS, POIS, ITEMS, MAP } from './config.js';
import { gunOf } from './actors.js';
import { equipAttachment } from './inv.js';
import { useHeal } from './combat.js';

const el = (tag, cls, html, parent) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; if (parent) parent.appendChild(e); return e; };
const BUTTONS = [['jump', 'JUMP'], ['crouch', 'CROUCH'], ['prone', 'PRONE'], ['reload', 'RELOAD'], ['ads', 'AIM'], ['cover', 'COVER'], ['skill', 'SKILL'], ['heal', 'HEAL'], ['swap', 'SWAP'], ['use', 'USE']];
const DIRS = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
const fmt = (s) => { const t = Math.ceil(Math.max(0, s)); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };

export function installErrorOverlay() {
  const box = el('div', 'errbox', '', document.body); box.style.display = 'none';
  const show = (m) => { box.style.display = 'block'; box.textContent = 'ERROR (tap to hide)\n' + m; };
  box.onclick = () => { box.style.display = 'none'; };
  window.addEventListener('error', (e) => show((e.message || 'error') + ' @' + (e.filename || '').split('/').pop() + ':' + (e.lineno || '')));
  window.addEventListener('unhandledrejection', (e) => show('Promise: ' + (e.reason && e.reason.message ? e.reason.message : e.reason)));
}

export function buildUI(app, G, cb) {
  const ui = { els: {} };
  let fullMap = false, miniT = 0, toastT = 0, hitT = 0, hurtT = 0, invOpen = false, invT = 0, hudT = 0;

  // ================= LOBBY =================
  const lobby = el('div', 'screen', '', app);
  el('h1', 'title', 'SHADOW FIRE', lobby);
  el('div', 'sub', 'Original battle royale &middot; 50 players &middot; one island', lobby);
  const modeBtn = el('button', 'btn big', '', lobby);
  const slots = el('div', 'row', '', lobby), slotBtns = [];
  for (let i = 0; i < 4; i++) slotBtns.push(el('button', 'btn slot', '', slots));
  el('div', 'lbl', 'Character ability', lobby);
  const abRow = el('div', 'row', '', lobby), abBtns = {};
  for (const k in ABILITIES) { const b = el('button', 'btn', '<b>' + ABILITIES[k].name + '</b><br><small>' + ABILITIES[k].desc + '</small>', abRow); b.onclick = () => { S.ability = k; save(); refresh(); }; abBtns[k] = b; }
  el('div', 'lbl', 'Pet', lobby);
  const petRow = el('div', 'row', '', lobby), petBtns = {};
  for (const k in PETS) { const b = el('button', 'btn', PETS[k], petRow); b.onclick = () => { S.pet = k; save(); refresh(); }; petBtns[k] = b; }
  const act = el('div', 'row', '', lobby);
  const startBtn = el('button', 'btn go', 'START MATCH', act), setBtn = el('button', 'btn', 'SETTINGS', act);
  el('div', 'hint', 'Left stick = move &middot; Right thumb drag = look (drag UP fast = head aim assist) &middot; FIRE button on the left<br>Desktop test: WASD, mouse (click to lock), LMB fire, RMB aim, C/Z stance, R reload, F cover, Q skill, H heal, E use', lobby);
  const refresh = () => {
    modeBtn.textContent = 'MODE: ' + (S.squad ? 'SQUAD (4)' : 'SOLO');
    slotBtns.forEach((b, i) => { b.textContent = i === 0 ? 'You' : !S.squad ? '-' : S.mates[i - 1] ? 'Bot mate' : 'Empty'; b.classList.toggle('dim', i > 0 && !S.squad); });
    for (const k in abBtns) abBtns[k].classList.toggle('sel', S.ability === k);
    for (const k in petBtns) petBtns[k].classList.toggle('sel', S.pet === k);
  };
  modeBtn.onclick = () => { S.squad = !S.squad; save(); refresh(); };
  slotBtns.forEach((b, i) => { b.onclick = () => { if (i > 0 && S.squad) { S.mates[i - 1] = !S.mates[i - 1]; save(); refresh(); } }; });
  setBtn.onclick = () => openSettings();
  refresh();

  // ================= HUD =================
  const hud = el('div', 'hud', '', app); hud.style.display = 'none';
  const look = el('div', 'look', '', hud);
  const mini = el('canvas', 'mini', '', hud); mini.width = 180; mini.height = 180;
  const mctx = mini.getContext('2d');
  mini.onclick = () => { fullMap = !fullMap; };
  const compass = el('div', 'compass', 'N 0', hud), zoneEl = el('div', 'zoneinfo', '', hud), aliveEl = el('div', 'alive', '', hud), feedEl = el('div', 'feed', '', hud);
  const cross = el('div', 'cross', '', hud), hitm = el('div', 'hitm', '&#10005;', hud), scope = el('div', 'scope', '', hud), vign = el('div', 'vign', '', hud);
  const toastEl = el('div', 'toast', '', hud), downEl = el('div', 'downed', 'YOU ARE DOWN - wait for a teammate', hud);
  const reviveEl = el('div', 'revive', '<div></div>', hud), reviveFill = reviveEl.firstChild;
  const bars = el('div', 'bars', '<div class="bar sh"><i></i></div><div class="bar hp"><i></i></div><div class="gear"></div>', hud);
  const shFill = bars.children[0].firstChild, hpFill = bars.children[1].firstChild, gearEl = bars.children[2];
  const ammoEl = el('div', 'ammo', '', hud);
  const joy = el('div', 'joy', '<div class="knob"></div>', hud), knob = joy.firstChild;
  const fire = el('div', 'fire', 'FIRE', hud);
  const grid = el('div', 'grid', '', hud), btnEls = [];
  for (const [a, t] of BUTTONS) { const b = el('div', 'abtn', t, grid); b.dataset.act = a; btnEls.push(b); }
  const gear = el('div', 'topbtn', '&#9881;', hud), bag = el('div', 'topbtn bag', '&#127890;', hud);
  gear.onclick = () => openSettings(); bag.onclick = () => { invOpen = !invOpen; inv.style.display = invOpen ? 'block' : 'none'; renderInv(G); };
  ui.els = { joy, knob, fire, look, buttons: btnEls, canvas: null };

  // ================= INVENTORY =================
  const inv = el('div', 'invpanel', '', app); inv.style.display = 'none';
  function renderInv(G) {
    const p = G.player; if (!p) return;
    let h = '<div class="ihead">BACKPACK ' + p.inv.used() + '/' + p.inv.capacity() + ' &middot; Vest ' + p.armor + ' &middot; Helm ' + p.helmet + ' &middot; Pack ' + p.inv.pack + '</div><div class="ilist">';
    p.guns.forEach((g, i) => { h += '<div class="irow' + (i === p.cur ? ' cur' : '') + '" data-g="' + i + '">' + (g ? g.def.name + ' ' + g.ammo + '/' + g.mag() + ' [' + Object.keys(g.att).join(',') + ']' : '(empty slot)') + '</div>'; });
    for (const id in p.inv.items) {
      const it = ITEMS[id], n = p.inv.items[id];
      h += '<div class="irow">' + it.name + ' x' + n + (it.type === 'heal' ? ' <u data-use="' + id + '">USE</u>' : '') + (it.type === 'att' ? ' <u data-eq="' + id + '">EQUIP</u>' : '') + '</div>';
    }
    inv.innerHTML = h + '</div><div class="ihint">Tap a weapon to switch &middot; BAG button closes</div>';
  }
  inv.onclick = (e) => {
    const t = e.target, p = G.player; if (!t || !t.dataset || !p) return;
    if (t.dataset.g !== undefined && p.guns[+t.dataset.g]) { p.cur = +t.dataset.g; p.ads = false; }
    if (t.dataset.use) useHeal(p);
    if (t.dataset.eq) equipAttachment(p, t.dataset.eq);
    renderInv(G);
  };

  // ================= SETTINGS =================
  let settings = null;
  function openSettings() {
    if (settings) return;
    settings = el('div', 'screen settings', '', app);
    el('h2', '', 'SETTINGS', settings);
    const wrap = el('div', 'srows', '', settings);
    const slider = (label, key, min, max, step) => {
      const r = el('div', 'srow', '<span>' + label + '</span>', wrap), v = el('b', '', String(S[key]), r), inp = el('input', '', '', r);
      inp.type = 'range'; inp.min = min; inp.max = max; inp.step = step; inp.value = S[key];
      inp.oninput = () => { S[key] = +inp.value; v.textContent = (+inp.value).toFixed(2); applyHud(); };
      v.textContent = (+S[key]).toFixed(2);
    };
    slider('Hip-fire sens', 'hip', 0.1, 3, 0.05); slider('ADS sens', 'ads', 0.1, 3, 0.05); slider('Scoped sens', 'scoped', 0.1, 3, 0.05);
    slider('Gyro sens', 'gyro', 0.1, 3, 0.05); slider('Curve exponent', 'exponent', 1, 2, 0.05); slider('HUD button scale', 'hudScale', 0.7, 1.4, 0.05);
    const cyc = (label, get, next) => { const b = el('button', 'btn', '', wrap); const upd = () => { b.textContent = label + ': ' + get(); }; b.onclick = () => { next(); save(); upd(); applyHud(); }; upd(); };
    cyc('Aim assist', () => S.assist.toUpperCase(), () => { const L = ['off', 'low', 'med', 'high']; S.assist = L[(L.indexOf(S.assist) + 1) % 4]; });
    cyc('Auto-fire', () => (S.autoFire ? 'ON' : 'OFF'), () => { S.autoFire = !S.autoFire; });
    cyc('Gyro aim', () => (S.gyroOn ? 'ON' : 'OFF'), () => { S.gyroOn = !S.gyroOn; });
    cyc('Graphics', () => S.quality.toUpperCase(), () => { const L = ['low', 'med', 'high']; S.quality = L[(L.indexOf(S.quality) + 1) % 3]; if (cb.onQuality) cb.onQuality(); });
    cyc('Fire button side', () => S.fireSide.toUpperCase(), () => { S.fireSide = S.fireSide === 'left' ? 'right' : 'left'; });
    const row = el('div', 'row', '', settings);
    const rs = el('button', 'btn', 'RESET SENS', row), cl = el('button', 'btn go', 'SAVE & CLOSE', row);
    rs.onclick = () => { resetSens(); closeSettings(); openSettings(); };
    cl.onclick = () => closeSettings();
  }
  function closeSettings() { save(); if (settings) { settings.remove(); settings = null; } applyHud(); }
  function applyHud() { hud.style.setProperty('--hs', S.hudScale); hud.classList.toggle('fire-right', S.fireSide === 'right'); }
  applyHud();

  // ================= RESULT =================
  ui.showResult = (r) => {
    const s = el('div', 'screen', '', app);
    el('h1', 'title', r.win ? 'VICTORY!' : 'ELIMINATED', s);
    el('div', 'sub', 'Placement #' + r.place + ' &middot; Kills ' + r.kills + ' &middot; Survived ' + fmt(r.time), s);
    const b = el('button', 'btn go', 'PLAY AGAIN', s); b.onclick = () => location.reload();
  };
  ui.hitmarker = (head) => { hitT = 0.14; hitm.style.opacity = 1; hitm.style.color = head ? '#ff3b3b' : '#ffffff'; };
  ui.hurt = () => { hurtT = 0.35; };
  ui.toast = (s) => { toastEl.textContent = s; toastEl.style.opacity = 1; toastT = 2; };
  ui.start = () => { lobby.style.display = 'none'; hud.style.display = 'block'; try { if (document.documentElement.requestFullscreen) document.documentElement.requestFullscreen(); } catch (e) { /* ignore */ } };
  startBtn.onclick = () => { save(); ui.start(); cb.onStart({ squad: S.squad, mates: S.mates.slice(), name: 'You' }); };

  // ================= PER-FRAME =================
  function drawMini(G) {
    const p = G.player, W = 180, c = mctx;
    const sc = fullMap ? W / (MAP.size * 0.5 * 2.2) : W / 440, cx = fullMap ? 0 : p.x, cz = fullMap ? 0 : p.z;
    const X = (x) => W / 2 + (x - cx) * sc, Z = (z) => W / 2 + (z - cz) * sc;
    c.fillStyle = '#245f93'; c.fillRect(0, 0, W, W);
    c.fillStyle = '#4c7f3a'; c.beginPath(); c.arc(X(0), Z(0), MAP.R * sc, 0, 7); c.fill();
    c.font = '10px sans-serif';
    for (const o of POIS) { c.fillStyle = '#f2e6b0'; c.fillRect(X(o.x) - 2, Z(o.z) - 2, 4, 4); if (!fullMap || true) { c.fillStyle = '#fff'; c.fillText(o.name.split(' ')[0], X(o.x) + 4, Z(o.z) + 3); } }
    const z = G.zone;
    c.lineWidth = 2; c.strokeStyle = '#ffffff'; c.beginPath(); c.arc(X(z.nx), Z(z.nz), z.nr * sc, 0, 7); c.stroke();
    c.strokeStyle = '#3aa0ff'; c.beginPath(); c.arc(X(z.cx), Z(z.cz), z.r * sc, 0, 7); c.stroke();
    c.fillStyle = '#ff3b3b'; for (const d of G.drops) c.fillRect(X(d.x) - 3, Z(d.z) - 3, 6, 6);
    c.fillStyle = '#d6c14a'; for (const v of G.vehicles) c.fillRect(X(v.x) - 2, Z(v.z) - 2, 4, 4);
    c.fillStyle = '#4aa8ff'; for (const a of G.actors) if (a !== p && a.team === p.team && !a.dead) { c.beginPath(); c.arc(X(a.x), Z(a.z), 3, 0, 7); c.fill(); }
    const px = X(p.x), pz = Z(p.z), dx = -Math.sin(p.yaw), dz = -Math.cos(p.yaw);
    c.fillStyle = '#fff'; c.beginPath(); c.moveTo(px + dx * 8, pz + dz * 8); c.lineTo(px - dx * 5 - dz * 5, pz - dz * 5 + dx * 5); c.lineTo(px - dx * 5 + dz * 5, pz - dz * 5 - dx * 5); c.closePath(); c.fill();
  }
  ui.update = (G, dt) => {
    const p = G.player; if (!p) return;
    const g = gunOf(p);
    hpFill.style.width = Math.max(0, p.hp / p.maxHp * 100) + '%'; shFill.style.width = Math.min(100, p.shield * 2) + '%';
    hpFill.style.background = p.downed ? '#d33' : p.hp < 35 ? '#e8a030' : '#3fd070';
    ammoEl.textContent = g ? (g.reloadUntil > 0 ? 'RELOADING' : g.ammo + ' / ' + g.mag() + '  +' + p.inv.count(g.def.ammo)) : 'NO WEAPON';
    const sc = g && g.scoped() && p.ads;
    scope.style.display = sc ? 'block' : 'none'; cross.style.display = sc ? 'none' : 'block';
    downEl.style.display = p.downed ? 'block' : 'none';
    reviveEl.style.display = G.reviveTarget ? 'block' : 'none'; if (G.reviveTarget) reviveFill.style.width = Math.min(100, G.reviveTarget.reviveProg / 5 * 100) + '%';
    hudT -= dt;
    if (hudT <= 0) {
      hudT = 0.1;
      const z = G.zone, hd = ((-p.yaw * 180 / Math.PI) % 360 + 360) % 360;
      compass.textContent = DIRS[Math.round(hd / 45) % 8] + '  ' + Math.round(hd) + '\u00b0';
      const out = z.outside(p.x, p.z);
      zoneEl.textContent = (z.finished ? 'FINAL ZONE' : z.shrinking ? 'ZONE CLOSING ' + fmt(z.t) : 'ZONE CLOSES IN ' + fmt(z.t)) + '  ' + z.dps + ' dmg/s' + (out ? '  !! OUTSIDE ZONE' : '');
      zoneEl.style.color = out ? '#ff5050' : '#fff';
      aliveEl.textContent = 'ALIVE ' + G.alive + '   KILLS ' + p.kills;
      gearEl.textContent = 'Vest ' + p.armor + '  Helm ' + p.helmet + '  Pack ' + p.inv.pack + (p.abReady > G.time ? '  Skill ' + Math.ceil(p.abReady - G.time) + 's' : '  Skill READY');
      const now = G.time; feedEl.innerHTML = G.feedList.filter((f) => now - f.t < 6).map((f) => '<div>' + f.s + '</div>').join('');
      if (invOpen) { invT -= 0.1; if (invT <= 0) { invT = 0.5; renderInv(G); } }
    }
    miniT -= dt; if (miniT <= 0) { miniT = 0.12; drawMini(G); }
    if (toastT > 0) { toastT -= dt; if (toastT <= 0) toastEl.style.opacity = 0; }
    if (hitT > 0) { hitT -= dt; if (hitT <= 0) hitm.style.opacity = 0; }
    if (hurtT > 0) { hurtT -= dt; vign.style.opacity = Math.max(0, hurtT / 0.35); } else vign.style.opacity = 0;
  };
  return ui;
}
