import { rand, pick } from './util.js';

export const MAP = { R: 950, size: 2000 };

export const POIS = [
  { name: 'Rustwater Docks',   x: 60,   z: -820, r: 110, tier: 3, rooms: 8 },
  { name: 'Ember Ridge',       x: -520, z: 180,  r: 120, tier: 3, rooms: 8 },
  { name: 'Glasswind Station', x: 480,  z: 380,  r: 100, tier: 2, rooms: 6 },
  { name: 'Hollow Pines',      x: -120, z: 560,  r: 100, tier: 2, rooms: 6 },
  { name: 'Saltmarsh Quarry',  x: -560, z: -380, r: 100, tier: 2, rooms: 6 },
  { name: 'Verdant Spire',     x: 620,  z: -300, r: 90,  tier: 1, rooms: 4 },
];

function pat(n, y0, y1, xa, seed) {
  const a = [];
  for (let i = 0; i < n; i++) { const t = i / Math.max(1, n - 1); a.push([Math.sin(i * 0.7 + seed) * xa * (1 + t), y0 + (y1 - y0) * t]); }
  return a;
}

// recoil[i] = [yaw wander deg, pitch climb deg] for shot i
export const WEAPONS = {
  ar:      { id: 'ar', name: 'Vanguard AR', ammo: 'ammo_556', dmg: 24, rpm: 600, mag: 30, reload: 2.1, auto: true, range: 140, hip: 2.2, adsMul: .35, perShot: .18, recover: 6, maxSpread: 5, sens: 1, adsFov: 50, pellets: 1, scope: false, recoil: pat(30, .42, .18, .12, 0), wander: .08, rrate: 3.5, ideal: 28 },
  smg:     { id: 'smg', name: 'Hornet SMG', ammo: 'ammo_9mm', dmg: 17, rpm: 900, mag: 35, reload: 1.8, auto: true, range: 90, hip: 2.6, adsMul: .4, perShot: .14, recover: 7, maxSpread: 5, sens: 1.1, adsFov: 55, pellets: 1, scope: false, recoil: pat(35, .28, .14, .16, 1), wander: .1, rrate: 4, ideal: 15 },
  shotgun: { id: 'shotgun', name: 'Thunder SG', ammo: 'ammo_shell', dmg: 11, rpm: 75, mag: 6, reload: 3.0, auto: false, range: 40, hip: 4.5, adsMul: .7, perShot: 0, recover: 6, maxSpread: 6, sens: .9, adsFov: 55, pellets: 9, scope: false, recoil: [[0, 2.2]], wander: .3, rrate: 4, ideal: 8 },
  sniper:  { id: 'sniper', name: 'Longbow SR', ammo: 'ammo_sniper', dmg: 95, rpm: 45, mag: 5, reload: 3.0, auto: false, range: 300, hip: 3, adsMul: .02, perShot: 0, recover: 6, maxSpread: 3, sens: .8, adsFov: 25, pellets: 1, scope: true, recoil: [[0, 2.8]], wander: .2, rrate: 3, ideal: 70 },
  pistol:  { id: 'pistol', name: 'Sidearm', ammo: 'ammo_9mm', dmg: 20, rpm: 300, mag: 12, reload: 1.4, auto: false, range: 70, hip: 2, adsMul: .4, perShot: .3, recover: 6, maxSpread: 4, sens: 1, adsFov: 58, pellets: 1, scope: false, recoil: pat(12, .3, .3, .05, 2), wander: .05, rrate: 4, ideal: 20 },
};

export const ITEMS = {
  ammo_556:   { name: '5.56 Ammo', type: 'ammo', stack: 90 },
  ammo_9mm:   { name: '9mm Ammo', type: 'ammo', stack: 90 },
  ammo_shell: { name: 'Shells', type: 'ammo', stack: 30 },
  ammo_sniper:{ name: 'Sniper Rounds', type: 'ammo', stack: 20 },
  bandage:    { name: 'Bandage', type: 'heal', stack: 5 },
  medkit:     { name: 'Medkit', type: 'heal', stack: 2 },
  armor1: { name: 'Vest I', type: 'armor', tier: 1, stack: 1 }, armor2: { name: 'Vest II', type: 'armor', tier: 2, stack: 1 }, armor3: { name: 'Vest III', type: 'armor', tier: 3, stack: 1 },
  helmet1: { name: 'Helm I', type: 'helmet', tier: 1, stack: 1 }, helmet2: { name: 'Helm II', type: 'helmet', tier: 2, stack: 1 }, helmet3: { name: 'Helm III', type: 'helmet', tier: 3, stack: 1 },
  pack1: { name: 'Pack I', type: 'pack', tier: 1, stack: 1 }, pack2: { name: 'Pack II', type: 'pack', tier: 2, stack: 1 }, pack3: { name: 'Pack III', type: 'pack', tier: 3, stack: 1 },
  att_muzzle: { name: 'Muzzle Brake', type: 'att', slot: 'muzzle', stack: 1 },
  att_grip:   { name: 'Steady Grip', type: 'att', slot: 'grip', stack: 1 },
  att_mag:    { name: 'Ext. Mag', type: 'att', slot: 'mag', stack: 1 },
  att_scope:  { name: 'Scope', type: 'att', slot: 'scope', stack: 1 },
  w_ar: { name: 'Vanguard AR', type: 'weapon', gun: 'ar', stack: 1 }, w_smg: { name: 'Hornet SMG', type: 'weapon', gun: 'smg', stack: 1 },
  w_shotgun: { name: 'Thunder SG', type: 'weapon', gun: 'shotgun', stack: 1 }, w_sniper: { name: 'Longbow SR', type: 'weapon', gun: 'sniper', stack: 1 },
  w_pistol: { name: 'Sidearm', type: 'weapon', gun: 'pistol', stack: 1 },
};
export const PACK_SLOTS = [8, 12, 16, 22];

const TABLES = {
  1: [['ammo_9mm', 20, 30], ['ammo_556', 18, 30], ['bandage', 18, 2], ['w_pistol', 10, 1], ['w_smg', 8, 1], ['w_shotgun', 6, 1], ['armor1', 6, 1], ['helmet1', 6, 1], ['pack1', 5, 1], ['w_ar', 4, 1]],
  2: [['ammo_556', 16, 30], ['ammo_9mm', 12, 30], ['ammo_shell', 8, 12], ['bandage', 12, 3], ['medkit', 7, 1], ['w_ar', 10, 1], ['w_smg', 8, 1], ['w_shotgun', 6, 1], ['armor2', 6, 1], ['helmet2', 6, 1], ['pack2', 5, 1], ['att_muzzle', 4, 1], ['att_grip', 4, 1], ['att_mag', 4, 1], ['w_sniper', 3, 1]],
  3: [['ammo_556', 12, 40], ['ammo_sniper', 6, 10], ['medkit', 10, 1], ['bandage', 8, 3], ['w_ar', 10, 1], ['w_sniper', 7, 1], ['w_smg', 6, 1], ['armor3', 7, 1], ['helmet3', 7, 1], ['pack3', 6, 1], ['att_scope', 7, 1], ['att_muzzle', 5, 1], ['att_grip', 5, 1], ['att_mag', 5, 1], ['ammo_9mm', 6, 30]],
};
export function rollLoot(tier) {
  const t = TABLES[tier] || TABLES[1];
  let sum = 0; for (const e of t) sum += e[1];
  let r = rand(0, sum);
  for (const e of t) { r -= e[1]; if (r <= 0) return { id: e[0], amount: e[2] > 1 ? Math.max(1, Math.round(e[2] * rand(.5, 1))) : 1 }; }
  return { id: t[0][0], amount: 1 };
}
export const AIRDROP_LOOT = [['w_sniper', 1], ['w_ar', 1], ['armor3', 1], ['helmet3', 1], ['pack3', 1], ['medkit', 2], ['ammo_556', 60], ['ammo_sniper', 15], ['att_scope', 1]];

export const ZONE_PHASES = [
  { wait: 70, shrink: 60, end: 620, dps: 1 }, { wait: 60, shrink: 55, end: 380, dps: 2 },
  { wait: 50, shrink: 50, end: 220, dps: 4 }, { wait: 45, shrink: 40, end: 120, dps: 6 },
  { wait: 35, shrink: 30, end: 60, dps: 8 }, { wait: 25, shrink: 25, end: 25, dps: 10 },
  { wait: 20, shrink: 20, end: 0, dps: 20 },
];
export const START_ZONE_R = 1100;

export const ABILITIES = {
  pulse: { name: 'Heal Pulse', cd: 20, desc: 'Heals you + nearby squad 30 HP' },
  dash: { name: 'Speed Dash', cd: 18, desc: '+70% speed for 2.5s' },
  aegis: { name: 'Shield Burst', cd: 25, desc: '50 shield for 6s' },
};
export const PETS = { none: 'No pet', fox: 'Ember Fox (slow regen)', hawk: 'Gale Hawk (+8% speed)' };
export const NAMES = ['Nova', 'Raze', 'Kiro', 'Vex', 'Juno', 'Orin', 'Sable', 'Tala', 'Zed', 'Mira', 'Rook', 'Ember', 'Frost', 'Echo', 'Drift', 'Onyx', 'Lynx', 'Pike', 'Blaze', 'Hex'];
export const botName = () => pick(NAMES) + '_' + Math.floor(rand(10, 99));
