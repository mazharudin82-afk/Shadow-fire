import * as THREE from 'three';
import { ZONE_PHASES, START_ZONE_R } from './config.js';
import { damageActor } from './combat.js';

export class Zone {
  constructor(G) {
    this.G = G; this.cx = 0; this.cz = 0; this.r = START_ZONE_R; this.idx = 0; this.shrinking = false; this.t = 0; this.dps = 0;
    this.nx = 0; this.nz = 0; this.nr = START_ZONE_R; this.tick = 0; this.finished = false; this.phaseChanged = false;
    this.mesh = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 300, 64, 1, true), new THREE.MeshBasicMaterial({ color: 0x2288ff, transparent: true, opacity: 0.2, side: THREE.DoubleSide }));
    G.scene.add(this.mesh); this.begin(0);
  }
  begin(i) {
    const p = ZONE_PHASES[i]; this.idx = i; this.shrinking = false; this.t = p.wait; this.dps = p.dps;
    this.r0 = this.r; this.c0x = this.cx; this.c0z = this.cz; this.nr = p.end;
    const a = Math.random() * Math.PI * 2, d = Math.sqrt(Math.random()) * Math.max(0, this.r - p.end);
    this.nx = this.cx + Math.cos(a) * d; this.nz = this.cz + Math.sin(a) * d; this.phaseChanged = true;
  }
  outside(x, z) { return Math.hypot(x - this.cx, z - this.cz) > this.r; }
  update(dt) {
    const G = this.G; this.phaseChanged = false;
    if (!this.finished) {
      this.t -= dt; const p = ZONE_PHASES[this.idx];
      if (!this.shrinking) { if (this.t <= 0) { this.shrinking = true; this.t = p.shrink; } }
      else {
        const k = 1 - Math.max(0, this.t / p.shrink);
        this.r = this.r0 + (this.nr - this.r0) * k; this.cx = this.c0x + (this.nx - this.c0x) * k; this.cz = this.c0z + (this.nz - this.c0z) * k;
        if (this.t <= 0) { if (this.idx + 1 < ZONE_PHASES.length) this.begin(this.idx + 1); else this.finished = true; }
      }
    }
    this.mesh.position.set(this.cx, 100, this.cz); this.mesh.scale.set(Math.max(0.05, this.r), 1, Math.max(0.05, this.r));
    this.tick += dt;
    if (this.tick >= 1) {
      this.tick -= 1;
      for (const a of G.actors) if (!a.dead && !a.air && this.outside(a.x, a.z)) damageActor(G, a, this.dps, 'chest', null, true);
    }
  }
}
