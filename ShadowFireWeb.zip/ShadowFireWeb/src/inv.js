import { ITEMS, PACK_SLOTS } from './config.js';
import { Gun } from './gun.js';

export class Inventory {
  constructor() { this.items = {}; this.pack = 0; }
  capacity() { return PACK_SLOTS[this.pack]; }
  used() { let s = 0; for (const id in this.items) s += Math.ceil(this.items[id] / ITEMS[id].stack); return s; }
  count(id) { return this.items[id] || 0; }
  add(id, n) {
    const it = ITEMS[id]; if (!it) return n;
    let added = 0;
    while (added < n) {
      const cur = this.items[id] || 0, inStack = cur % it.stack;
      if (cur > 0 && inStack !== 0) { const t = Math.min(n - added, it.stack - inStack); this.items[id] = cur + t; added += t; continue; }
      if (this.used() >= this.capacity()) break;
      const t = Math.min(n - added, it.stack); this.items[id] = cur + t; added += t;
    }
    return n - added;
  }
  take(id, n) {
    const c = this.count(id), t = Math.min(c, n);
    if (t > 0) { this.items[id] = c - t; if (this.items[id] === 0) delete this.items[id]; }
    return t;
  }
}

/// returns leftover amount (what could NOT be picked up)
export function giveItem(a, id, n) {
  const it = ITEMS[id]; if (!it) return n;
  switch (it.type) {
    case 'armor': if (it.tier > a.armor) { a.armor = it.tier; return n - 1; } return n;
    case 'helmet': if (it.tier > a.helmet) { a.helmet = it.tier; return n - 1; } return n;
    case 'pack': if (it.tier > a.inv.pack) { a.inv.pack = it.tier; return n - 1; } return n;
    case 'weapon': {
      const slot = a.guns[0] ? (a.guns[1] ? -1 : 1) : 0;
      if (slot < 0) return n;
      a.guns[slot] = new Gun(it.gun);
      if (!a.guns[a.cur]) a.cur = slot;
      return n - 1;
    }
    case 'att': {
      const g = a.guns[a.cur];
      if (g && !g.att[it.slot]) { g.att[it.slot] = true; if (it.slot === 'mag') g.ammo = Math.min(g.ammo, g.mag()); return n - 1; }
      return a.inv.add(id, n);
    }
    default: return a.inv.add(id, n);
  }
}
/// swap current weapon with a weapon on the ground (drops the old one)
export function swapWeapon(a, id) {
  const it = ITEMS[id]; if (!it || it.type !== 'weapon') return null;
  const old = a.guns[a.cur]; a.guns[a.cur] = new Gun(it.gun);
  return old ? 'w_' + old.id : null;
}
export function equipAttachment(a, id) {
  const it = ITEMS[id], g = a.guns[a.cur];
  if (!it || it.type !== 'att' || !g || a.inv.count(id) < 1) return false;
  a.inv.take(id, 1);
  if (g.att[it.slot]) a.inv.add(id, 1); // swap: old goes back
  g.att[it.slot] = true; return true;
}

import { ITEMS as _ITEMS } from './config.js';
import { sfx } from './sfx.js';
/// auto pickup of everything within reach (weapons only if a slot is free)
export function tryPickup(G, a, reach = 1.8) {
  const loots = G.world.loots;
  for (let i = loots.length - 1; i >= 0; i--) {
    const l = loots[i];
    if (Math.abs(l.x - a.x) > reach || Math.abs(l.z - a.z) > reach || Math.abs(l.y - a.y) > 3) continue;
    const left = giveItem(a, l.id, l.amount), took = l.amount - left;
    if (took > 0) {
      if (a.isPlayer) { G.hooks.toast('+' + took + ' ' + _ITEMS[l.id].name); sfx.pick(); }
      l.amount = left; if (left <= 0) G.world.removeLoot(l);
    }
  }
}
