import * as THREE from 'three';
import { clamp } from './util.js';
import { damageActor } from './combat.js';

export function createVehicle(G, x, z) {
  const g = new THREE.Group(), body = new THREE.MeshLambertMaterial({ color: 0x4a6b3a }), dark = new THREE.MeshLambertMaterial({ color: 0x222222 });
  const add = (geo, mat, px, py, pz) => { const m = new THREE.Mesh(geo, mat); m.position.set(px, py, pz); g.add(m); };
  add(new THREE.BoxGeometry(2.2, 0.8, 4.2), body, 0, 0.8, 0); add(new THREE.BoxGeometry(1.9, 0.7, 1.8), body, 0, 1.45, 0.3);
  for (const sx of [-1, 1]) for (const sz of [-1.4, 1.4]) add(new THREE.BoxGeometry(0.3, 0.7, 0.7), dark, sx * 1.15, 0.35, sz);
  G.scene.add(g);
  const y = G.world.groundAt(x, z, 99);
  const v = { x, y, z, vy: 0, yaw: Math.random() * 6.28, speed: 0, radius: 1.6, height: 1.5, grounded: false, driver: null, mesh: g };
  g.position.set(x, y, z); G.vehicles.push(v); return v;
}
export function driveVehicle(G, v, I, dt) {
  const target = I.move.y > 0 ? I.move.y * 22 : I.move.y * 8;
  v.speed += (target - v.speed) * Math.min(1, dt * 1.5);
  v.yaw -= I.move.x * 1.4 * Math.sign(v.speed || 1) * Math.min(1, Math.abs(v.speed) / 8) * dt;
  const dx = -Math.sin(v.yaw) * v.speed * dt, dz = -Math.cos(v.yaw) * v.speed * dt, px = v.x, pz = v.z;
  G.world.moveActor(v, dx, dz, dt);
  if (Math.hypot(v.x - px, v.z - pz) < Math.hypot(dx, dz) * 0.5) v.speed *= 0.5;
  if (Math.abs(v.speed) > 8) for (const a of G.actors) {
    if (a === v.driver || a.dead || a.team === v.driver.team || Math.abs(a.y - v.y) > 3) continue;
    if (Math.hypot(a.x - v.x, a.z - v.z) < 2.2) damageActor(G, a, Math.abs(v.speed) * 3, 'chest', v.driver);
  }
}
export function syncVehicle(v) { v.mesh.position.set(v.x, v.y, v.z); v.mesh.rotation.y = v.yaw; }
