import * as THREE from 'three';
import { buildWorld } from './world.js';
import { createActor, syncMesh } from './actors.js';
import { makeFx } from './fx.js';
import { Zone } from './zone.js';
import { makeAI, updateBot } from './ai.js';
import { updatePlayer } from './player.js';
import { createVehicle } from './vehicle.js';
import { giveItem } from './inv.js';
import { tickGuns, tickHeal, damageActor } from './combat.js';
import { makeInputState, clearPulses } from './input.js';
import { POIS, AIRDROP_LOOT, botName } from './config.js';
import { rand, pick } from './util.js';

export function createGame(scene, hooks = {}) {
  const G = {
    scene, hooks: Object.assign({ hitmarker() {}, hurt() {}, toast() {}, onDeath() {}, end() {}, feed() {} }, hooks),
    actors: [], vehicles: [], drops: [], time: 0, ended: false, feedList: [], input: makeInputState(),
    cam: { pos: { x: 0, y: 30, z: 0 }, yaw: 0, pitch: 0, fov: 70 }, alive: 0, player: null, reviveTarget: null, zone: null, started: false,
  };
  G.feed = (s) => { G.feedList.push({ s, t: G.time }); if (G.feedList.length > 6) G.feedList.shift(); G.hooks.feed(s); };
  G.world = buildWorld(G); G.fx = makeFx(G);
  return G;
}

function landingTarget() {
  if (Math.random() < 0.3) { const a = rand(0, 6.28), d = Math.sqrt(Math.random()) * 700; return { x: Math.cos(a) * d, z: Math.sin(a) * d }; }
  const bag = []; POIS.forEach((p) => { for (let i = 0; i <= p.tier; i++) bag.push(p); });
  const p = pick(bag); return { x: p.x + rand(-50, 50), z: p.z + rand(-50, 50) };
}
function spawnPoint() { for (;;) { const x = rand(-650, 650), z = rand(-650, 650); if (Math.hypot(x, z) < 700) return { x, z }; } }
function starter(a) { giveItem(a, 'w_pistol', 1); a.inv.add('ammo_9mm', 60); a.inv.add('bandage', 2); }

export function startMatch(G, cfg) {
  const colors = [0xd04a3a, 0xd0a53a, 0x3fa653, 0x9a4ad0, 0x3ac7c7, 0xd06fa0, 0x8a8a8a, 0xe07a30];
  const sp = spawnPoint();
  const p = createActor(G, { name: cfg.name || 'You', team: 1, isPlayer: true, x: sp.x, y: 190, z: sp.z, air: true, color: 0x2a63c4 });
  G.player = p; starter(p);
  if (cfg.squad) for (const on of cfg.mates) if (on) {
    const m = createActor(G, { name: botName(), team: 1, x: sp.x + rand(-10, 10), y: 190, z: sp.z + rand(-10, 10), air: true, color: 0x4a8be0 });
    const t = { x: sp.x, z: sp.z }; m.ai = makeAI(t.x, t.z); starter(m);
  }
  const remaining = 50 - G.actors.length, size = cfg.squad ? 4 : 1; let team = 1, base = null, tgt = null;
  for (let i = 0; i < remaining; i++) {
    if (i % size === 0) { team++; base = spawnPoint(); tgt = landingTarget(); }
    const b = createActor(G, { name: botName(), team, x: base.x + rand(-10, 10), y: 190, z: base.z + rand(-10, 10), air: true, color: colors[team % colors.length] });
    b.ai = makeAI(tgt.x + rand(-15, 15), tgt.z + rand(-15, 15)); starter(b);
  }
  G.zone = new Zone(G);
  G.world.jeepSpawns.slice(0, 4).forEach((s) => createVehicle(G, s.x, s.z));
  G.started = true; G.alive = G.actors.length;
}

function spawnDrop(G) {
  const z = G.zone; let x = 0, zz = 0;
  for (let i = 0; i < 20; i++) { const a = rand(0, 6.28), d = Math.sqrt(Math.random()) * z.r * 0.6; x = z.cx + Math.cos(a) * d; zz = z.cz + Math.sin(a) * d; if (G.world.heightAt(x, zz) > 1) break; }
  const g = new THREE.Group();
  g.add(new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.2, 1.4), new THREE.MeshLambertMaterial({ color: 0xd9a21b })));
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 90, 6), new THREE.MeshBasicMaterial({ color: 0xff3b3b })); beam.position.y = 45; g.add(beam);
  G.scene.add(g); G.drops.push({ x, z: zz, y: 220, landed: false, mesh: g }); G.feed('Airdrop incoming!'); G.hooks.toast('AIRDROP incoming');
}
function updateDrops(G, dt) {
  if (!G.firstDrop && G.time > 25) { G.firstDrop = true; spawnDrop(G); }
  if (G.zone.phaseChanged && G.zone.idx >= 1) spawnDrop(G);
  for (let i = G.drops.length - 1; i >= 0; i--) {
    const d = G.drops[i];
    if (!d.landed) { d.y -= 7 * dt; const gh = G.world.groundAt(d.x, d.z, 99); if (d.y <= gh + 0.6) { d.y = gh + 0.6; d.landed = true; } }
    d.mesh.position.set(d.x, d.y, d.z);
    if (!d.landed) continue;
    for (const a of G.actors) {
      if (a.dead || a.downed || a.air || Math.hypot(a.x - d.x, a.z - d.z) > 2.6) continue;
      for (const [id, n] of AIRDROP_LOOT) G.world.spawnLoot(id, d.x + rand(-2, 2), d.z + rand(-2, 2), n);
      G.scene.remove(d.mesh); G.drops.splice(i, 1); if (a.isPlayer) G.hooks.toast('Airdrop opened!'); break;
    }
  }
}

function checkEnd(G) {
  if (G.ended) return;
  const teams = new Set(); for (const a of G.actors) if (!a.dead) teams.add(a.team);
  const p = G.player, mine = teams.has(p.team);
  if (p.dead || (teams.size <= 1 && mine)) {
    G.ended = true;
    G.hooks.end({ win: !p.dead && teams.size <= 1, place: p.dead ? teams.size + (mine ? 0 : 1) : 1, kills: p.kills, time: G.time });
  }
}

export function stepGame(G, dt) {
  if (!G.started || G.ended) return;
  G.time += dt;
  updatePlayer(G, dt);
  for (const a of G.actors) {
    if (!a.isPlayer) updateBot(G, a, dt);
    tickGuns(G, a, dt); tickHeal(a, dt);
    if (a.downed && !a.dead) { a.downedHp -= 1.2 * dt; if (a.downedHp <= 0) damageActor(G, a, 1, 'chest', null, true); }
    if (a.shieldUntil && G.time > a.shieldUntil) { a.shield = 0; a.shieldUntil = 0; }
    if (a.dashUntil && G.time > a.dashUntil) { a.speedMul = 1; a.dashUntil = 0; }
  }
  G.zone.update(dt); updateDrops(G, dt); G.world.update(dt); G.fx.update(dt);
  let n = 0; for (const a of G.actors) if (!a.dead) n++; G.alive = n;
  clearPulses(G.input);
  checkEnd(G);
}
export function syncVisuals(G) {
  const c = G.cam.pos; for (const a of G.actors) syncMesh(a, c.x, c.z);
  for (const v of G.vehicles) { v.mesh.position.set(v.x, v.y, v.z); v.mesh.rotation.y = v.yaw; }
}
