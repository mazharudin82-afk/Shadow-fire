export function makeInputState() {
  return { move: { x: 0, y: 0 }, lookPx: { x: 0, y: 0 }, fire: false, held: {}, pulse: {}, gyro: { x: 0, y: 0 } };
}
export function clearPulses(I) { for (const k in I.pulse) I.pulse[k] = false; }

/// Binds touch (pointer events) + keyboard/mouse (desktop testing) to the input state.
/// els = { joy, knob, fire, look, buttons: [elements with data-act], canvas }
export function bindInput(I, els, S) {
  // ---- joystick ----
  let jid = null;
  const upd = (e) => {
    const r = els.joy.getBoundingClientRect(), R = r.width / 2;
    let dx = (e.clientX - (r.left + R)) / R, dy = (e.clientY - (r.top + R)) / R; const l = Math.hypot(dx, dy);
    if (l > 1) { dx /= l; dy /= l; }
    I.move.x = dx; I.move.y = -dy;
    els.knob.style.transform = 'translate(calc(-50% + ' + dx * R * 0.6 + 'px), calc(-50% + ' + dy * R * 0.6 + 'px))';
  };
  const jend = (e) => { if (e.pointerId === jid) { jid = null; I.move.x = I.move.y = 0; els.knob.style.transform = 'translate(-50%,-50%)'; } };
  els.joy.addEventListener('pointerdown', (e) => { jid = e.pointerId; els.joy.setPointerCapture(e.pointerId); upd(e); e.preventDefault(); });
  els.joy.addEventListener('pointermove', (e) => { if (e.pointerId === jid) upd(e); });
  els.joy.addEventListener('pointerup', jend); els.joy.addEventListener('pointercancel', jend);

  // ---- fire (hold) ----
  let fid = null;
  els.fire.addEventListener('pointerdown', (e) => { fid = e.pointerId; els.fire.setPointerCapture(e.pointerId); I.fire = true; e.preventDefault(); });
  const fend = (e) => { if (e.pointerId === fid) { fid = null; I.fire = false; } };
  els.fire.addEventListener('pointerup', fend); els.fire.addEventListener('pointercancel', fend);

  // ---- look: right thumb drag ----
  let lid = null, lx = 0, ly = 0;
  els.look.addEventListener('pointerdown', (e) => { if (lid !== null) return; lid = e.pointerId; lx = e.clientX; ly = e.clientY; els.look.setPointerCapture(e.pointerId); e.preventDefault(); });
  els.look.addEventListener('pointermove', (e) => {
    if (e.pointerId !== lid) return;
    I.lookPx.x += e.clientX - lx; I.lookPx.y += -(e.clientY - ly); lx = e.clientX; ly = e.clientY;
  });
  const lend = (e) => { if (e.pointerId === lid) lid = null; };
  els.look.addEventListener('pointerup', lend); els.look.addEventListener('pointercancel', lend);

  // ---- action buttons ----
  for (const b of els.buttons) {
    const act = b.dataset.act;
    b.addEventListener('pointerdown', (e) => { I.held[act] = true; I.pulse[act] = true; b.classList.add('on'); b.setPointerCapture(e.pointerId); e.preventDefault(); });
    const up = () => { I.held[act] = false; b.classList.remove('on'); };
    b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up);
  }

  // ---- keyboard + mouse (desktop test) ----
  const kd = new Set(); let kbdActive = false;
  const map = { Space: 'jump', KeyC: 'crouch', KeyZ: 'prone', KeyR: 'reload', KeyF: 'cover', KeyQ: 'skill', KeyH: 'heal', KeyE: 'use', Digit1: 'swap' };
  const recompute = () => {
    if (!kbdActive && kd.size === 0) return;
    I.move.x = (kd.has('KeyD') ? 1 : 0) - (kd.has('KeyA') ? 1 : 0); I.move.y = (kd.has('KeyW') ? 1 : 0) - (kd.has('KeyS') ? 1 : 0);
    kbdActive = kd.size > 0;
  };
  window.addEventListener('keydown', (e) => {
    kd.add(e.code); const a = map[e.code]; if (a && !e.repeat) { I.pulse[a] = true; I.held[a] = true; } recompute();
  });
  window.addEventListener('keyup', (e) => { kd.delete(e.code); const a = map[e.code]; if (a) I.held[a] = false; recompute(); });
  if (els.canvas) {
    els.canvas.addEventListener('mousedown', (e) => {
      if (!document.pointerLockElement && els.canvas.requestPointerLock && !('ontouchstart' in window)) els.canvas.requestPointerLock();
      if (e.button === 0) I.fire = true; if (e.button === 2) I.pulse.ads = true;
    });
    window.addEventListener('mouseup', (e) => { if (e.button === 0) I.fire = false; });
    els.canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    window.addEventListener('mousemove', (e) => { if (document.pointerLockElement) { I.lookPx.x += e.movementX * 1.5; I.lookPx.y += -e.movementY * 1.5; } });
  }

  // ---- gyro (experimental) ----
  let lastT = 0;
  window.addEventListener('devicemotion', (e) => {
    const now = performance.now(), dt = lastT ? Math.min(0.1, (now - lastT) / 1000) : 0; lastT = now;
    if (!S.gyroOn || !e.rotationRate) return;
    const flip = (screen.orientation && screen.orientation.angle === 270) ? -1 : 1, r = e.rotationRate;
    I.gyro.x += -(r.beta || 0) * dt * flip; I.gyro.y += -(r.gamma || 0) * dt * flip * -1;
  });
}
