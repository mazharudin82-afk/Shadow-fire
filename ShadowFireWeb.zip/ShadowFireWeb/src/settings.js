import { clamp } from './util.js';
const KEY = 'sf_web_settings_v1';
function load() { try { return JSON.parse(localStorage.getItem(KEY) || '{}'); } catch (e) { return {}; } }
export const DEFAULTS = { hip: 1, ads: .7, scoped: .4, gyro: 1, exponent: 1.35, assist: 'med', autoFire: false, gyroOn: false, quality: 'med', hudScale: 1, fireSide: 'left', squad: false, ability: 'pulse', pet: 'none', mates: [true, true, true] };
export const S = Object.assign({}, DEFAULTS, load());
export function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { /* ignore */ } }
export function resetSens() { Object.assign(S, { hip: 1, ads: .7, scoped: .4, gyro: 1, exponent: 1.35, assist: 'med', autoFire: false, gyroOn: false }); save(); }

export const DEG_PER_PX = 0.2;
/// drag px (this frame) -> degrees. Per-mode (hip/ads/scoped) and per-gun scale; exponent curve on drag speed
export function toDegrees(px, dt, mode, gunScale) {
  const mult = mode === 'scoped' ? S.scoped : mode === 'ads' ? S.ads : S.hip;
  const speed = dt > 0 ? Math.hypot(px.x, px.y) / dt : 0;
  const gain = clamp(Math.pow(Math.max(speed, 1) / 600, S.exponent - 1), 0.6, 3);
  const k = DEG_PER_PX * mult * gunScale * gain;
  return { x: px.x * k, y: px.y * k };
}
