import { toDegrees, S } from './settings.js';
import { dirFrom, clamp, rand } from './util.js';
import { SPEED, EYE, gunOf, rightOf } from './actors.js';
import { fireGun, startReload, currentSpread, reviveTick, useHeal } from './combat.js';
import { updateAssist, redirect } from './aim.js';
import { swapWeapon, tryPickup } from './inv.js';
import { ABILITIES } from './config.js';
import { sfx } from './sfx.js';
import { driveVehicle, syncVehicle } from './vehicle.js';

const DEG = Math.PI / 180;

export function cameraPose(G, dt) {
  const p = G.player, g = gunOf(p), veh = p.vehicle;
  const ads = p.ads && !veh;
  const tgt = ads ? [0.45, 0.05, -1.5] : veh ? [0, 1.6, -7] : [0.6, 0.1, -2.8];
  const o = p._off || (p._off = tgt.slice());
  const k = Math.min(1, dt * 14);
  for (let i = 0; i < 3; i++) o[i] += (tgt[i] - o[i]) * k;
  const fovT = ads && g ? g.adsFov() : veh ? 80 : 70;
  p._fov = (p._fov || 70) + (fovT - (p._fov || 70)) * k;
  const base = veh ? { x: veh.x, y: veh.y + 1.5, z: veh.z } : { x: p.x, y: p.y + EYE[p.stance] + 0.1, z: p.z };
  const f = dirFrom(p.yaw, p.pitch), r = { x: Math.cos(p.yaw), z: -Math.sin(p.yaw) };
  let pos = { x: base.x + r.x * o[0] + f.x * o[2], y: base.y + o[1] + f.y * o[2], z: base.z + r.z * o[0] + f.z * o[2] };
  const vx = pos.x - base.x, vy = pos.y - base.y, vz = pos.z - base.z, len = Math.hypot(vx, vy, vz) || 1;
  const dir = { x: vx / len, y: vy / len, z: vz / len }, hit = G.world.raycast(base, dir, len);
  if (hit.t < len) { const t = Math.max(0.3, hit.t - 0.25); pos = { x: base.x + dir.x * t, y: base.y + dir.y * t, z: base.z + dir.z * t }; }
  const gh = G.world.heightAt(pos.x, pos.z) + 0.3; if (pos.y < gh) pos.y = gh;
  G.cam = { pos, yaw: p.yaw, pitch: p.pitch, fov: p._fov };
}

function shootPlayer(G, p, g) {
  const cam = G.cam;
  const d = redirect(p, cam.pos, dirFrom(p.yaw, p.pitch));
  fireGun(G, p, g, cam.pos, d, currentSpread(p, g));
  const i = Math.min(g.shot, g.def.recoil.length - 1), m = g.recoilMul() * (p.ads ? 0.75 : 1);
  const rx = (g.def.recoil[i][0] + rand(-1, 1) * g.def.wander) * m, ry = g.def.recoil[i][1] * m;
  g.shot++; p.yaw += rx * DEG; p.pitch += ry * DEG; g.recoilAcc[0] += rx; g.recoilAcc[1] += ry;
}

export function useAbility(G, p) {
  if (G.time < (p.abReady || 0)) return false;
  const ab = ABILITIES[S.ability]; p.abReady = G.time + ab.cd;
  if (S.ability === 'pulse') { for (const a of G.actors) if (!a.dead && !a.downed && a.team === p.team && Math.hypot(a.x - p.x, a.z - p.z) < 8) a.hp = Math.min(a.maxHp, a.hp + 30); }
  else if (S.ability === 'dash') { p.speedMul = 1.7; p.dashUntil = G.time + 2.5; }
  else { p.shield = 50; p.shieldUntil = G.time + 6; }
  G.hooks.toast(ab.name + '!'); return true;
}

export function updatePlayer(G, dt) {
  const p = G.player, I = G.input, pulse = I.pulse;
  if (p.dead) { cameraPose(G, dt); I.lookPx.x = I.lookPx.y = 0; return; }
  const g = gunOf(p);

  // ---- look (drag -> degrees through the sensitivity model) ----
  const mode = p.ads ? (g && g.scoped() ? 'scoped' : 'ads') : 'hip';
  const deg = toDegrees(I.lookPx, dt, mode, g ? g.def.sens : 1);
  if (S.gyroOn) { deg.x += I.gyro.x * S.gyro; deg.y += I.gyro.y * S.gyro; }
  I.lookPx.x = I.lookPx.y = 0; I.gyro.x = I.gyro.y = 0;
  p.yaw -= deg.x * DEG; p.pitch = clamp(p.pitch + deg.y * DEG, -1.1, 1.2);
  const dragUp = dt > 0 ? deg.y / dt : 0;
  updateAssist(G, p, G.cam.pos, dirFrom(p.yaw, p.pitch), dragUp, dt);

  // ---- vehicle ----
  if (p.vehicle) {
    const v = p.vehicle; driveVehicle(G, v, I, dt); syncVehicle(v);
    p.x = v.x; p.y = v.y; p.z = v.z;
    if (pulse.use) { const r = rightOf(p); p.vehicle = null; v.driver = null; v.speed = 0; p.x = v.x + r.x * 2.4; p.z = v.z + r.z * 2.4; }
    cameraPose(G, dt); return;
  }

  // ---- air (parachute) ----
  if (p.air) {
    const f = { x: -Math.sin(p.yaw), z: -Math.cos(p.yaw) }, r = rightOf(p);
    p.x += (f.x * I.move.y + r.x * I.move.x) * 14 * dt; p.z += (f.z * I.move.y + r.z * I.move.x) * 14 * dt;
    p.y -= 11 * dt; const gh = G.world.groundAt(p.x, p.z, p.y + 5);
    if (p.y <= gh) { p.y = gh; p.air = false; p.vy = 0; }
    cameraPose(G, dt); return;
  }

  // ---- stance / ads ----
  if (pulse.crouch) p.stance = p.stance === 1 ? 0 : 1;
  if (pulse.prone) p.stance = p.stance === 2 ? 0 : 2;
  if (pulse.ads && g && !p.downed) p.ads = !p.ads;
  if (p.downed) { p.ads = false; p.stance = 2; }
  if (!g) p.ads = false;

  // ---- move ----
  const hawk = S.pet === 'hawk' ? 1.08 : 1;
  const sp = p.downed ? 1 : SPEED[p.stance] * p.speedMul * hawk * (p.ads ? 0.7 : 1);
  const f = { x: -Math.sin(p.yaw), z: -Math.cos(p.yaw) }, r = rightOf(p);
  let dx = f.x * I.move.y + r.x * I.move.x, dz = f.z * I.move.y + r.z * I.move.x;
  const l = Math.hypot(dx, dz); if (l > 1) { dx /= l; dz /= l; }
  G.world.moveActor(p, dx * sp * dt, dz * sp * dt, dt);
  if (pulse.jump && p.grounded && p.stance === 0 && !p.downed) p.vy = 6.2;

  // ---- weapons ----
  if (pulse.swap && p.guns[p.cur ^ 1]) { if (g) g.reloadUntil = 0; p.cur ^= 1; p.ads = false; }
  const gun = gunOf(p);
  if (gun && !p.downed) {
    const trigger = I.fire || (S.autoFire && p.aim && p.aim.target);
    const edge = trigger && !p._wasTrig; p._wasTrig = trigger;
    if (trigger && G.time >= gun.next && gun.reloadUntil === 0 && (gun.def.auto || edge)) {
      if (gun.ammo <= 0) { if (!startReload(G, p)) sfx.empty(); } else shootPlayer(G, p, gun);
    }
    if (pulse.reload) startReload(G, p);
    if (G.time - gun.last > 0.35) gun.shot = 0;
    if (G.time - gun.last > 0.12) {          // recoil recovery
      const ax = gun.recoilAcc[0], ay = gun.recoilAcc[1], m = Math.hypot(ax, ay);
      if (m > 1e-4) { const step = Math.min(m, gun.def.rrate * dt), k = step / m; p.yaw -= ax * k * DEG; p.pitch -= ay * k * DEG; gun.recoilAcc[0] -= ax * k; gun.recoilAcc[1] -= ay * k; }
    }
  } else p._wasTrig = false;

  // ---- abilities / cover / heal ----
  if (pulse.skill && !p.downed) useAbility(G, p);
  if (pulse.cover && !p.downed && G.time >= (p.coverReady || 0)) { p.coverReady = G.time + 8; G.world.addWall(p.x + f.x * 2.2, p.z + f.z * 2.2, p.yaw); }
  if (pulse.heal) useHeal(p);
  if (S.pet === 'fox' && p.hp < 60 && !p.downed && G.time - p.lastHit > 5) p.hp = Math.min(60, p.hp + 0.6 * dt);

  // ---- use: vehicle / weapon swap / revive ----
  let tm = null, bd = 2.6;
  for (const a of G.actors) if (a !== p && a.downed && !a.dead && a.team === p.team) { const d = Math.hypot(a.x - p.x, a.z - p.z); if (d < bd) { bd = d; tm = a; } }
  G.reviveTarget = null;
  if (tm && I.held.use) { G.reviveTarget = tm; reviveTick(G, tm, dt); }
  else if (pulse.use && !p.downed) {
    let veh = null, vd = 4;
    for (const v of G.vehicles) { const d = Math.hypot(v.x - p.x, v.z - p.z); if (d < vd && !v.driver) { vd = d; veh = v; } }
    if (veh) { p.vehicle = veh; veh.driver = p; p.ads = false; }
    else {
      let lw = null, ld = 2.6;
      for (const l of G.world.loots) { if (!l.id.startsWith('w_')) continue; const d = Math.hypot(l.x - p.x, l.z - p.z); if (d < ld) { ld = d; lw = l; } }
      if (lw) { const dropId = swapWeapon(p, lw.id); G.world.removeLoot(lw); if (dropId) G.world.spawnLoot(dropId, p.x + 0.8, p.z, 1); }
    }
  }
  p._pick = (p._pick || 0) - dt; if (p._pick <= 0) { p._pick = 0.15; tryPickup(G, p); }
  cameraPose(G, dt);
}
