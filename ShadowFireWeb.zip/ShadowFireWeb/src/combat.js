import { clamp, lerp, rand, raySeg, norm3 } from './util.js';
import { hitShapes, eyePos, rightOf } from './actors.js';
import { sfx } from './sfx.js';

const ARMOR = [0, 0.2, 0.3, 0.4], HELM = [0, 0.25, 0.35, 0.45], PART = { head: 2.2, chest: 1, limb: 0.65 };

export function hasMate(G, t) { for (const a of G.actors) if (a !== t && a.team === t.team && !a.dead && !a.downed) return true; return false; }

export function damageActor(G, t, dmg, part, att, raw = false) {
  if (t.dead) return 0;
  if (att && att !== t && att.team === t.team) return 0;
  let d = dmg;
  if (!raw) { d *= PART[part] || 1; d *= part === 'head' ? 1 - HELM[t.helmet] : 1 - ARMOR[t.armor]; }
  if (t.shield > 0) { const a = Math.min(t.shield, d); t.shield -= a; d -= a; }
  t.lastHit = G.time; t.healing = null;
  if (t.isPlayer) { sfx.hurt(); G.hooks.hurt(att); }
  if (t.downed) { t.downedHp -= d; if (t.downedHp <= 0) kill(G, t, att); return d; }
  t.hp -= d;
  if (t.hp <= 0) { if (hasMate(G, t)) down(G, t, att); else kill(G, t, att); }
  return d;
}
function down(G, t, by) {
  t.hp = 0; t.downed = true; t.downedHp = 60; t.reviveProg = 0; t.ads = false; t.stance = 2;
  G.feed((by ? by.name : 'Zone') + ' knocked ' + t.name);
}
function kill(G, t, by) {
  t.hp = 0; t.dead = true; t.downed = false;
  if (by && by !== t) by.kills++;
  G.feed((by ? by.name : 'Zone') + ' eliminated ' + t.name);
  const w = G.world, drop = (id, n) => w.spawnLoot(id, t.x + rand(-1.2, 1.2), t.z + rand(-1.2, 1.2), n);
  for (const g of t.guns) if (g) drop('w_' + g.id, 1);
  for (const id in t.inv.items) drop(id, t.inv.items[id]);
  if (t.armor) drop('armor' + t.armor, 1);
  if (t.helmet) drop('helmet' + t.helmet, 1);
  if (t.inv.pack) drop('pack' + t.inv.pack, 1);
  G.hooks.onDeath(t, by);
}

export function currentSpread(a, g) {
  const base = g.def.hip * (a.ads ? g.def.adsMul : 1) + g.spreadAcc;
  return Math.min(g.def.maxSpread, base * g.spreadMul());
}
function spreadDir(d, deg) {
  const up = Math.abs(d.y) > 0.95 ? { x: 1, y: 0, z: 0 } : { x: 0, y: 1, z: 0 };
  let rx = d.y * up.z - d.z * up.y, ry = d.z * up.x - d.x * up.z, rz = d.x * up.y - d.y * up.x;
  const rl = Math.hypot(rx, ry, rz) || 1; rx /= rl; ry /= rl; rz /= rl;
  const ux = ry * d.z - rz * d.y, uy = rz * d.x - rx * d.z, uz = rx * d.y - ry * d.x;
  const rad = Math.tan(deg * Math.PI / 180) * Math.sqrt(Math.random()), ang = Math.random() * Math.PI * 2;
  const cx = Math.cos(ang) * rad, cy = Math.sin(ang) * rad;
  return norm3({ x: d.x + rx * cx + ux * cy, y: d.y + ry * cx + uy * cy, z: d.z + rz * cx + uz * cy });
}

export function hitscan(G, shooter, o, d, range) {
  const best = { t: range, actor: null, part: null, box: null };
  const wr = G.world.raycast(o, d, range);
  if (wr.t < best.t) { best.t = wr.t; best.box = wr.box; }
  for (const a of G.actors) {
    if (a.dead || a.team === shooter.team) continue;
    const dx = a.x - o.x, dz = a.z - o.z, along = dx * d.x + dz * d.z;
    if (along < -2 || along > best.t + 2) continue;
    if (Math.abs(dx * d.z - dz * d.x) > 3) continue;
    for (const s of hitShapes(a)) {
      const r = raySeg(o, d, s.a, s.b);
      if (r.d < s.r && r.s < best.t) { best.t = r.s; best.actor = a; best.part = s.part; best.box = null; }
    }
  }
  return best;
}

export function fireGun(G, shooter, g, o, d, spreadDeg) {
  g.ammo--; g.next = G.time + 60 / g.def.rpm; g.last = G.time; g.spreadAcc += g.def.perShot;
  const r = rightOf(shooter), e = eyePos(shooter);
  for (let i = 0; i < g.def.pellets; i++) {
    const dir = spreadDir(d, g.def.pellets > 1 ? Math.max(spreadDeg, 3) : spreadDeg);
    const h = hitscan(G, shooter, o, dir, g.def.range);
    const end = { x: o.x + dir.x * h.t, y: o.y + dir.y * h.t, z: o.z + dir.z * h.t };
    if (h.actor) {
      const fall = lerp(1, 0.6, h.t / g.def.range);
      damageActor(G, h.actor, g.def.dmg * fall, h.part, shooter);
      if (shooter.isPlayer) { G.hooks.hitmarker(h.part === 'head'); if (h.part === 'head') sfx.head(); else sfx.hit(); }
    } else if (h.box && h.box.hp !== undefined) G.world.damageBox(h.box, g.def.dmg);
    if (i < 3) G.fx.tracer({ x: e.x + r.x * 0.3 + dir.x, y: e.y - 0.15, z: e.z + r.z * 0.3 + dir.z }, end);
  }
  if (shooter.isPlayer) sfx.shot();
}

export function startReload(G, a) {
  const g = a.guns[a.cur];
  if (!g || g.reloadUntil > 0 || g.ammo >= g.mag() || a.inv.count(g.def.ammo) <= 0) return false;
  g.reloadUntil = G.time + g.def.reload; return true;
}
export function tickGuns(G, a, dt) {
  for (const g of a.guns) {
    if (!g) continue;
    g.spreadAcc = Math.max(0, g.spreadAcc - g.def.recover * dt);
    if (g.reloadUntil > 0 && G.time >= g.reloadUntil) { g.ammo += a.inv.take(g.def.ammo, g.mag() - g.ammo); g.reloadUntil = 0; }
  }
}
export function reviveTick(G, target, dt) {
  target.reviveProg += dt;
  if (target.reviveProg >= 5) { target.downed = false; target.hp = 30; target.reviveProg = 0; target.stance = 0; return true; }
  return false;
}
export function useHeal(a) {
  const id = a.inv.count('medkit') > 0 && a.hp < a.maxHp * 0.5 ? 'medkit' : a.inv.count('bandage') > 0 ? 'bandage' : a.inv.count('medkit') > 0 ? 'medkit' : null;
  if (!id || a.hp >= a.maxHp || a.downed || a.healing) return false;
  a.healing = { id, t: id === 'medkit' ? 4 : 2 }; return true;
}
export function tickHeal(a, dt) {
  const h = a.healing; if (!h) return;
  h.t -= dt;
  if (h.t <= 0) {
    if (a.inv.take(h.id, 1) > 0) a.hp = h.id === 'medkit' ? a.maxHp : Math.min(a.hp + 15, Math.max(a.hp, 75));
    a.healing = null;
  }
}
