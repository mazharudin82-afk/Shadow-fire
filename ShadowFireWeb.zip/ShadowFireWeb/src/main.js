import * as THREE from 'three';
import './style.css';
import { createGame, startMatch, stepGame, syncVisuals } from './game.js';
import { S } from './settings.js';
import { bindInput } from './input.js';
import { buildUI, installErrorOverlay } from './ui.js';

installErrorOverlay();
const app = document.getElementById('app');
const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
const applyQuality = () => { renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, S.quality === 'low' ? 1 : S.quality === 'med' ? 1.5 : 2)); renderer.setSize(window.innerWidth, window.innerHeight); camera.aspect = window.innerWidth / window.innerHeight; camera.updateProjectionMatrix(); };
const camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.1, 900); camera.rotation.order = 'YXZ';
app.appendChild(renderer.domElement);
applyQuality(); window.addEventListener('resize', applyQuality);

const scene = new THREE.Scene();
let ui = null;
const G = createGame(scene, {
  hitmarker: (h) => ui && ui.hitmarker(h), hurt: () => ui && ui.hurt(), toast: (s) => ui && ui.toast(s), end: (r) => ui && ui.showResult(r),
});
ui = buildUI(app, G, { onStart: (cfg) => startMatch(G, cfg), onQuality: applyQuality });
ui.els.canvas = renderer.domElement;
bindInput(G.input, ui.els, S);

let last = performance.now(), orbit = 0;
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  if (G.started) {
    stepGame(G, dt); syncVisuals(G);
    const c = G.cam; camera.position.set(c.pos.x, c.pos.y, c.pos.z); camera.rotation.set(c.pitch, c.yaw, 0);
    if (Math.abs(camera.fov - c.fov) > 0.01) { camera.fov = c.fov; camera.updateProjectionMatrix(); }
    ui.update(G, dt);
  } else { // lobby background: slow orbit over the island
    orbit += dt * 0.05; camera.position.set(Math.cos(orbit) * 380, 160, Math.sin(orbit) * 380); camera.lookAt(0, 0, 0);
  }
  renderer.render(scene, camera);
}
requestAnimationFrame(frame);
