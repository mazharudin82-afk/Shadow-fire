export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const lerp = (a, b, t) => a + (b - a) * t;
export const rand = (a = 0, b = 1) => a + Math.random() * (b - a);
export const randInt = (a, b) => Math.floor(rand(a, b + 1));
export const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
export const dist2 = (ax, az, bx, bz) => Math.hypot(ax - bx, az - bz);
export function mulberry(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export function shuffle(arr, rng = Math.random) {
  for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; }
  return arr;
}
export function norm3(v) { const l = Math.hypot(v.x, v.y, v.z) || 1; return { x: v.x / l, y: v.y / l, z: v.z / l }; }
/// yaw 0 faces -Z, pitch>0 looks up
export function dirFrom(yaw, pitch) {
  const cp = Math.cos(pitch);
  return { x: -Math.sin(yaw) * cp, y: Math.sin(pitch), z: -Math.cos(yaw) * cp };
}
/// closest distance between ray (o + s*d, |d|=1, s>=0) and segment ab -> {d, s}
export function raySeg(o, d, a, b) {
  const vx = b.x - a.x, vy = b.y - a.y, vz = b.z - a.z;
  const wx = o.x - a.x, wy = o.y - a.y, wz = o.z - a.z;
  const uv = d.x * vx + d.y * vy + d.z * vz, vv = vx * vx + vy * vy + vz * vz;
  const uw = d.x * wx + d.y * wy + d.z * wz, vw = vx * wx + vy * wy + vz * wz;
  const den = vv - uv * uv;
  let t;
  if (vv < 1e-9) t = 0;
  else if (den < 1e-9) t = 0.5;
  else { const s0 = (uv * vw - uw * vv) / den; t = (s0 * uv + vw) / vv; }
  t = clamp(t, 0, 1);
  const px = a.x + vx * t, py = a.y + vy * t, pz = a.z + vz * t;
  const s = Math.max(0, (px - o.x) * d.x + (py - o.y) * d.y + (pz - o.z) * d.z);
  return { d: Math.hypot(o.x + d.x * s - px, o.y + d.y * s - py, o.z + d.z * s - pz), s };
}
/// ray vs AABB {x0,x1,y0,y1,z0,z1} -> t or Infinity
export function rayAABB(o, d, b, maxT) {
  let t0 = 0, t1 = maxT;
  const ax = [o.x, d.x, b.x0, b.x1, o.y, d.y, b.y0, b.y1, o.z, d.z, b.z0, b.z1];
  for (let i = 0; i < 12; i += 4) {
    const oo = ax[i], dd = ax[i + 1], mn = ax[i + 2], mx = ax[i + 3];
    if (Math.abs(dd) < 1e-9) { if (oo < mn || oo > mx) return Infinity; }
    else {
      let a = (mn - oo) / dd, c = (mx - oo) / dd;
      if (a > c) { const tmp = a; a = c; c = tmp; }
      if (a > t0) t0 = a; if (c < t1) t1 = c;
      if (t0 > t1) return Infinity;
    }
  }
  return t0;
}
