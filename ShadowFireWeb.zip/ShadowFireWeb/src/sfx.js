let ctx = null;
function ac() { if (ctx === null) { try { ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { ctx = false; } } return ctx; }
function tone(f, d, type = 'square', vol = 0.07) {
  const c = ac(); if (!c) return;
  try {
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.value = f; g.gain.value = vol;
    g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + d);
    o.connect(g); g.connect(c.destination); o.start(); o.stop(c.currentTime + d);
  } catch (e) { /* ignore */ }
}
export const sfx = {
  shot() { tone(130, .07, 'sawtooth', .08); }, hit() { tone(900, .05, 'square', .05); }, head() { tone(1400, .09, 'square', .07); },
  pick() { tone(600, .06, 'triangle', .05); }, hurt() { tone(90, .15, 'sawtooth', .09); }, empty() { tone(300, .04, 'square', .04); },
};
