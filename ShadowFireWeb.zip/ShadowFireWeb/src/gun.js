import { WEAPONS } from './config.js';
export class Gun {
  constructor(id) { this.id = id; this.def = WEAPONS[id]; this.att = {}; this.next = 0; this.last = -9; this.shot = 0; this.spreadAcc = 0; this.reloadUntil = 0; this.recoilAcc = [0, 0]; this.ammo = this.def.mag; }
  mag() { return this.def.mag + (this.att.mag ? 10 : 0); }
  recoilMul() { return (this.att.muzzle ? 0.85 : 1) * (this.att.grip ? 0.9 : 1); }
  spreadMul() { return this.att.grip ? 0.8 : 1; }
  scoped() { return !!this.att.scope || this.def.scope; }
  adsFov() { return this.def.adsFov * (this.att.scope ? 0.6 : 1); }
}
