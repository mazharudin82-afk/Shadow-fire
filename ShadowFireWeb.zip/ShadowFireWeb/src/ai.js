import { SPEED, gunOf, eyePos, keypoints } from './actors.js';
import { fireGun, startReload, useHeal, reviveTick } from './combat.js';
import { tryPickup } from './inv.js';
import { dirFrom, norm3, rand, clamp } from './util.js';
import { ITEMS } from './config.js';

const DEG = Math.PI / 180;
const angDiff = (a, b) => { let d = (b - a) % (Math.PI * 2); if (d > Math.PI) d -= Math.PI * 2; if (d < -Math.PI) d += Math.PI * 2; return d; };
const turnToward = (a, b, m) => a + clamp(angDiff(a, b), -m, m);

export function makeAI(tx, tz) {
  return { t: Math.random() * 0.3, mode: 'loot', tx, tz, enemy: null, react: 0, seen: -99, strafe: 1, strafeT: 0, burst: 0, burstPause: 0, blockT: 0, lx: 0, lz: 0, avoid: 0, avoidT: 0, mate: null };
}

function visible(G, b, a) {
  const o = eyePos(b), t = keypoints(a).top, dx = t.x - o.x, dy = t.y - o.y, dz = t.z - o.z, dist = Math.hypot(dx, dy, dz);
  const r = G.world.raycast(o, { x: dx / dist, y: dy / dist, z: dz / dist }, dist);
  return r.t >= dist - 0.6;
}
function wanted(b, l) {
  const it = ITEMS[l.id], g = gunOf(b);
  switch (it.type) {
    case 'weapon': return !g || !b.guns[1];
    case 'ammo': return b.guns.some((x) => x && x.def.ammo === l.id) && b.inv.count(l.id) < 120;
    case 'heal': return b.inv.count(l.id) < 4;
    case 'armor': return it.tier > b.armor; case 'helmet': return it.tier > b.helmet; case 'pack': return it.tier > b.inv.pack;
    case 'att': return !!g && !g.att[it.slot];
    default: return false;
  }
}

function think(G, b) {
  const ai = b.ai, zone = G.zone;
  let enemy = null, bd = 85 * 85;
  for (const a of G.actors) {
    if (a.dead || a.team === b.team || a.air) continue;
    const dx = a.x - b.x, dz = a.z - b.z, d2 = dx * dx + dz * dz;
    if (d2 < bd && visible(G, b, a)) { enemy = a; bd = d2; }
  }
  if (enemy) { if (ai.enemy !== enemy) ai.react = G.time + 0.4 + Math.random() * 0.5; ai.enemy = enemy; ai.seen = G.time; }
  else if (G.time - ai.seen > 3) ai.enemy = null;
  if (ai.enemy && ai.enemy.dead) ai.enemy = null;

  // pick the best usable weapon (dps, must have ammo)
  let bi = b.cur, bs = -1;
  b.guns.forEach((x, i) => { if (!x || (x.ammo <= 0 && b.inv.count(x.def.ammo) <= 0)) return; const sc = x.def.dmg * x.def.pellets * x.def.rpm / 60 * (x.def.auto ? 1 : 0.8); if (sc > bs) { bs = sc; bi = i; } });
  if (bi !== b.cur && b.guns[bi]) { const old = gunOf(b); if (old) old.reloadUntil = 0; b.cur = bi; }
  const g = gunOf(b);
  tryPickup(G, b);
  if (b.hp < 55 && G.time - b.lastHit > 3 && !ai.enemy) useHeal(b);

  if (ai.enemy && g && (g.ammo > 0 || b.inv.count(g.def.ammo) > 0)) { ai.mode = 'fight'; return; }
  ai.mode = 'roam';
  if (Math.hypot(b.x - zone.cx, b.z - zone.cz) > zone.r * 0.85) { ai.mode = 'zone'; const a = Math.random() * 6.28; ai.tx = zone.cx + Math.cos(a) * zone.r * 0.3; ai.tz = zone.cz + Math.sin(a) * zone.r * 0.3; return; }
  for (const a of G.actors) if (a.team === b.team && a.downed && !a.dead) { ai.mode = 'revive'; ai.mate = a; ai.tx = a.x; ai.tz = a.z; return; }
  let best = null, bd2 = 200 * 200;
  for (const l of G.world.loots) { const dx = l.x - b.x, dz = l.z - b.z, d2 = dx * dx + dz * dz; if (d2 < bd2 && wanted(b, l)) { best = l; bd2 = d2; } }
  if (best) { ai.mode = 'loot'; ai.tx = best.x; ai.tz = best.z; return; }
  if (b.team === 1 && G.player && !G.player.dead && Math.hypot(b.x - G.player.x, b.z - G.player.z) > 22) { ai.mode = 'follow'; ai.tx = G.player.x; ai.tz = G.player.z; return; }
  if (Math.hypot(ai.tx - b.x, ai.tz - b.z) < 4 || ai.mode0 !== 'roam') {
    const a = Math.random() * 6.28, d = rand(40, 160);
    let tx = b.x + Math.cos(a) * d, tz = b.z + Math.sin(a) * d;
    const dz = Math.hypot(tx - zone.cx, tz - zone.cz); if (dz > zone.r * 0.8) { tx = zone.cx + (tx - zone.cx) * zone.r * 0.8 / dz; tz = zone.cz + (tz - zone.cz) * zone.r * 0.8 / dz; }
    ai.tx = tx; ai.tz = tz;
  }
  ai.mode0 = 'roam';
}

export function updateBot(G, b, dt) {
  if (b.dead) return;
  const ai = b.ai;
  if (b.air) {
    const dx = ai.tx - b.x, dz = ai.tz - b.z, l = Math.hypot(dx, dz);
    if (l > 3) { b.x += dx / l * 14 * dt; b.z += dz / l * 14 * dt; b.yaw = Math.atan2(-dx, -dz); }
    b.y -= 11 * dt; const gh = G.world.groundAt(b.x, b.z, b.y + 5);
    if (b.y <= gh) { b.y = gh; b.air = false; b.vy = 0; }
    return;
  }
  if (b.downed) return;
  ai.t -= dt; if (ai.t <= 0) { ai.t = 0.25 + Math.random() * 0.15; think(G, b); }
  act(G, b, dt);
}

function act(G, b, dt) {
  const ai = b.ai, g = gunOf(b);
  if (b.healing) { G.world.moveActor(b, 0, 0, dt); return; }
  const sp = SPEED[0] * b.speedMul;
  let mx = 0, mz = 0;
  if (ai.mode === 'fight' && ai.enemy) {
    const e = ai.enemy, dx = e.x - b.x, dz = e.z - b.z, dist = Math.hypot(dx, dz) || 1;
    const o = eyePos(b), p = keypoints(e).top, dir = norm3({ x: p.x - o.x, y: p.y - o.y, z: p.z - o.z });
    const wantYaw = Math.atan2(-dir.x, -dir.z);
    b.yaw = turnToward(b.yaw, wantYaw, 6 * dt);
    const ideal = g ? g.def.ideal : 20, nx = dx / dist, nz = dz / dist;
    if (dist > ideal + 6) { mx = nx; mz = nz; } else if (dist < ideal - 6) { mx = -nx; mz = -nz; }
    ai.strafeT -= dt; if (ai.strafeT <= 0) { ai.strafe = Math.random() < 0.5 ? -1 : 1; ai.strafeT = rand(0.8, 2); }
    mx += -nz * ai.strafe * 0.6; mz += nx * ai.strafe * 0.6;
    ai.burstPause -= dt;
    if (g && G.time > ai.react && g.reloadUntil === 0) {
      if (g.ammo <= 0) { if (!startReload(G, b)) ai.enemy = null; }
      else if (G.time >= g.next && Math.abs(angDiff(b.yaw, wantYaw)) < 0.14 && ai.burstPause <= 0) {
        const err = (2.2 + dist * 0.03) * DEG;
        fireGun(G, b, g, o, dirFrom(wantYaw + rand(-err, err), Math.asin(clamp(dir.y, -1, 1)) + rand(-err, err) * 0.7), 0);
        ai.burst++; if (ai.burst >= (g.def.auto ? 7 : 2)) { ai.burst = 0; ai.burstPause = rand(0.4, 1); }
      }
    }
  } else {
    const dx = ai.tx - b.x, dz = ai.tz - b.z, d = Math.hypot(dx, dz);
    if (ai.mode === 'revive' && ai.mate && ai.mate.downed && d < 2) { reviveTick(G, ai.mate, dt); G.world.moveActor(b, 0, 0, dt); return; }
    if (d > 1.2) { mx = dx / d; mz = dz / d; b.yaw = turnToward(b.yaw, Math.atan2(-mx, -mz), 8 * dt); } else ai.t = 0;
  }
  const l = Math.hypot(mx, mz);
  if (l > 0) {
    mx /= l; mz /= l;
    if (ai.avoidT > 0) { ai.avoidT -= dt; const c = Math.cos(ai.avoid * 1.2), s = Math.sin(ai.avoid * 1.2); const nx = mx * c - mz * s; mz = mx * s + mz * c; mx = nx; }
  }
  ai.blockT += dt;
  if (ai.blockT > 0.5) {
    if (l > 0 && Math.hypot(b.x - ai.lx, b.z - ai.lz) < sp * 0.5 * 0.4) { ai.avoid = Math.random() < 0.5 ? 1 : -1; ai.avoidT = 1.2; }
    ai.lx = b.x; ai.lz = b.z; ai.blockT = 0;
  }
  G.world.moveActor(b, mx * sp * dt, mz * sp * dt, dt);
}
