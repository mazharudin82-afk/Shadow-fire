import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { MAP, POIS, ITEMS, rollLoot } from './config.js';
import { clamp, lerp, rayAABB, mulberry, shuffle } from './util.js';

const CELL = 24;
const key = (ix, iz) => (ix + 200) * 1000 + (iz + 200);
const sm = (t) => t * t * (3 - 2 * t);

export function heightAt(x, z) {
  const r = Math.hypot(x, z) / MAP.R;
  const mask = clamp(1 - r * r * r, 0, 1);
  const hills = 5 * Math.sin(x * 0.004 + 0.5) * Math.cos(z * 0.0035) + 2.5 * Math.sin(x * 0.011 + 1.3) * Math.sin(z * 0.009) + 0.8 * Math.sin(x * 0.03) * Math.cos(z * 0.027);
  let h = 14 * mask - 2.2 + hills * mask;
  for (const p of POIS) {
    const d = Math.hypot(x - p.x, z - p.z);
    if (d < p.r * 1.3) h = lerp(h, 3, sm(clamp((p.r * 1.3 - d) / (p.r * 0.5), 0, 1)));
  }
  return h;
}
function shade(hex, a) {
  const r = clamp(((hex >> 16) & 255) + a, 0, 255), g = clamp(((hex >> 8) & 255) + a, 0, 255), b = clamp((hex & 255) + a, 0, 255);
  return (r << 16) | (g << 8) | b;
}
const lootColor = (id) => { const t = ITEMS[id].type; return t === 'ammo' ? 0xf2c230 : t === 'heal' ? 0xe84057 : t === 'weapon' ? 0xff8c2a : t === 'att' ? 0x4cd96b : 0x4aa8ff; };

export function buildWorld(G) {
  const scene = G.scene;
  scene.background = new THREE.Color(0x8ec9f2);
  scene.fog = new THREE.Fog(0x8ec9f2, 160, 720);
  scene.add(new THREE.HemisphereLight(0xdfefff, 0x556b3a, 0.9));
  const sun = new THREE.DirectionalLight(0xffffff, 0.8); sun.position.set(200, 300, 100); scene.add(sun);

  const W = { cells: new Map(), loots: [], stamp: 0, pois: POIS, jeepSpawns: [], rising: [], heightAt };

  // ---------- terrain + water ----------
  const tg = new THREE.PlaneGeometry(MAP.size, MAP.size, 160, 160); tg.rotateX(-Math.PI / 2);
  const pos = tg.attributes.position, cols = new Float32Array((pos.count || 0) * 3);
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i), h = heightAt(x, z); pos.setY(i, h);
    let c = h < 0.6 ? [0.85, 0.78, 0.55] : h < 9 ? [0.34, 0.55, 0.25] : [0.45, 0.42, 0.38];
    const j = (Math.sin(x * 0.13) * Math.cos(z * 0.11)) * 0.04;
    cols[i * 3] = c[0] + j; cols[i * 3 + 1] = c[1] + j; cols[i * 3 + 2] = c[2] + j;
  }
  tg.setAttribute('color', new THREE.BufferAttribute(cols, 3)); tg.computeVertexNormals();
  scene.add(new THREE.Mesh(tg, new THREE.MeshLambertMaterial({ vertexColors: true })));
  const water = new THREE.Mesh(new THREE.PlaneGeometry(9000, 9000).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0x2d79b8 }));
  water.position.y = -1; scene.add(water);

  // ---------- spatial grid ----------
  W.insert = (b) => {
    b.s = 0;
    for (let ix = Math.floor(b.x0 / CELL); ix <= Math.floor(b.x1 / CELL); ix++)
      for (let iz = Math.floor(b.z0 / CELL); iz <= Math.floor(b.z1 / CELL); iz++) {
        const k = key(ix, iz); let a = W.cells.get(k); if (!a) { a = []; W.cells.set(k, a); } a.push(b);
      }
  };
  W.removeBox = (b) => {
    for (let ix = Math.floor(b.x0 / CELL); ix <= Math.floor(b.x1 / CELL); ix++)
      for (let iz = Math.floor(b.z0 / CELL); iz <= Math.floor(b.z1 / CELL); iz++) {
        const a = W.cells.get(key(ix, iz)); if (a) { const i = a.indexOf(b); if (i >= 0) a.splice(i, 1); }
      }
    if (b.mesh) scene.remove(b.mesh);
  };
  W.near = (x, z, r) => {
    const out = []; W.stamp++;
    for (let ix = Math.floor((x - r) / CELL); ix <= Math.floor((x + r) / CELL); ix++)
      for (let iz = Math.floor((z - r) / CELL); iz <= Math.floor((z + r) / CELL); iz++) {
        const a = W.cells.get(key(ix, iz)); if (!a) continue;
        for (const b of a) if (b.s !== W.stamp) { b.s = W.stamp; out.push(b); }
      }
    return out;
  };
  W.groundAt = (x, z, feetY) => {
    let g = heightAt(x, z);
    for (const b of W.near(x, z, 0.05)) if (x >= b.x0 && x <= b.x1 && z >= b.z0 && z <= b.z1 && b.y1 <= feetY + 0.7 && b.y1 > g) g = b.y1;
    return g;
  };
  W.moveActor = (a, dx, dz, dt) => {
    let nx = a.x + dx, nz = a.z + dz;
    for (let it = 0; it < 2; it++) {
      for (const b of W.near(nx, nz, a.radius + 0.1)) {
        if (b.y1 <= a.y + 0.7 || a.y + a.height <= b.y0) continue;
        const cx = clamp(nx, b.x0, b.x1), cz = clamp(nz, b.z0, b.z1), ddx = nx - cx, ddz = nz - cz, d2 = ddx * ddx + ddz * ddz;
        if (d2 >= a.radius * a.radius) continue;
        if (d2 > 1e-8) { const d = Math.sqrt(d2), push = a.radius - d; nx += ddx / d * push; nz += ddz / d * push; }
        else {
          const l = nx - b.x0, r = b.x1 - nx, f = nz - b.z0, k = b.z1 - nz, m = Math.min(l, r, f, k);
          if (m === l) nx = b.x0 - a.radius; else if (m === r) nx = b.x1 + a.radius; else if (m === f) nz = b.z0 - a.radius; else nz = b.z1 + a.radius;
        }
      }
    }
    if (W.groundAt(nx, nz, a.y) < -0.8 && W.groundAt(a.x, a.z, a.y) >= -0.8) { nx = a.x; nz = a.z; } // water blocks
    a.x = nx; a.z = nz;
    const g = W.groundAt(a.x, a.z, a.y);
    a.vy -= 22 * dt; a.y += a.vy * dt;
    if (a.y <= g) { a.y = g; a.vy = 0; a.grounded = true; } else a.grounded = false;
  };
  W.raycast = (o, d, maxT) => {
    let bt = maxT, bb = null; W.stamp++;
    for (let s = 0; s <= maxT; s += 4) {
      const a = W.cells.get(key(Math.floor((o.x + d.x * s) / CELL), Math.floor((o.z + d.z * s) / CELL)));
      if (!a) continue;
      for (const b of a) { if (b.s === W.stamp) continue; b.s = W.stamp; const t = rayAABB(o, d, b, bt); if (t < bt) { bt = t; bb = b; } }
    }
    for (let s = 2; s < bt; s += 2) if (o.y + d.y * s < heightAt(o.x + d.x * s, o.z + d.z * s)) { bt = Math.max(0, s - 1); bb = null; break; }
    return { t: bt, box: bb };
  };
  W.damageBox = (b, dmg) => { b.hp -= dmg; if (b.hp <= 0) W.removeBox(b); };

  // ---------- loot ----------
  const lootGeo = new THREE.BoxGeometry(0.4, 0.4, 0.4);
  W.spawnLoot = (id, x, z, amount) => {
    if (!ITEMS[id]) return null;
    const y = W.groundAt(x, z, 99) + 0.35;
    const mesh = new THREE.Mesh(lootGeo, new THREE.MeshBasicMaterial({ color: lootColor(id) })); mesh.position.set(x, y, z); scene.add(mesh);
    const l = { id, x, y, z, amount, mesh }; W.loots.push(l); return l;
  };
  W.removeLoot = (l) => { scene.remove(l.mesh); const i = W.loots.indexOf(l); if (i >= 0) W.loots.splice(i, 1); };

  // ---------- frost wall (deployable cover) ----------
  W.addWall = (x, z, yaw, hp = 160) => {
    const alongZ = Math.abs(Math.sin(yaw)) > Math.abs(Math.cos(yaw));
    const hx = alongZ ? 0.25 : 1.6, hz = alongZ ? 1.6 : 0.25, y0 = W.groundAt(x, z, 99);
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(hx * 2, 2.2, hz * 2), new THREE.MeshLambertMaterial({ color: 0x9fdcff, transparent: true, opacity: 0.85 }));
    mesh.position.set(x, y0 + 1.1, z); mesh.scale.y = 0.05; scene.add(mesh);
    const b = { x0: x - hx, x1: x + hx, z0: z - hz, z1: z + hz, y0, y1: y0 + 2.2, hp, mesh };
    W.insert(b); W.rising.push({ mesh, y0, t: 0 }); return b;
  };
  W.update = (dt) => {
    for (let i = W.rising.length - 1; i >= 0; i--) {
      const r = W.rising[i]; r.t += dt / 0.35; const k = Math.min(1, r.t);
      r.mesh.scale.y = Math.max(0.05, k); r.mesh.position.y = r.y0 + 1.1 * k;
      if (k >= 1) W.rising.splice(i, 1);
    }
  };

  // ---------- buildings (merged into one mesh) ----------
  const geos = [];
  const sbox = (cx, by, cz, w, h, d, col, collide = true) => {
    const g = new THREE.BoxGeometry(w, h, d); g.translate(cx, by + h / 2, cz);
    const n = g.attributes.position.count || 0, c = new Float32Array(n * 3), cc = new THREE.Color(col);
    for (let i = 0; i < n; i++) { c[i * 3] = cc.r; c[i * 3 + 1] = cc.g; c[i * 3 + 2] = cc.b; }
    g.setAttribute('color', new THREE.BufferAttribute(c, 3)); geos.push(g);
    if (collide) W.insert({ x0: cx - w / 2, x1: cx + w / 2, y0: by, y1: by + h, z0: cz - d / 2, z1: cz + d / 2 });
  };
  const room = (cx, cz, w, d, h, col) => {
    const by = heightAt(cx, cz), t = 0.4, door = 3, seg = (w - door) / 2, dh = 2.4;
    sbox(cx, by, cz, w, 0.2, d, shade(col, -35));
    sbox(cx, by, cz + d / 2, w, h, t, col);
    sbox(cx - w / 2, by, cz, t, h, d, col); sbox(cx + w / 2, by, cz, t, h, d, col);
    sbox(cx - (door / 2 + seg / 2), by, cz - d / 2, seg, h, t, col); sbox(cx + (door / 2 + seg / 2), by, cz - d / 2, seg, h, t, col);
    sbox(cx, by + dh, cz - d / 2, door, h - dh, t, col);
    sbox(cx, by + h, cz, w + 0.4, 0.25, d + 0.4, shade(col, -50));
    return by;
  };
  const palette = [0xb8a58c, 0x9aa7b0, 0xc4b08a, 0xa68b7a, 0x8fa595];
  const crateMat = new THREE.MeshLambertMaterial({ color: 0x9a6b35 }), crateGeo = new THREE.BoxGeometry(1.2, 1.2, 1.2);
  const crate = (x, z) => {
    const y0 = heightAt(x, z), mesh = new THREE.Mesh(crateGeo, crateMat); mesh.position.set(x, y0 + 0.6, z); scene.add(mesh);
    W.insert({ x0: x - 0.6, x1: x + 0.6, z0: z - 0.6, z1: z + 0.6, y0, y1: y0 + 1.2, hp: 120, mesh });
  };

  POIS.forEach((p, pi) => {
    const rng = mulberry(1000 + pi * 77), cells = [];
    for (let gx = -1; gx <= 1; gx++) for (let gz = -1; gz <= 1; gz++) cells.push([gx, gz]);
    shuffle(cells, rng);
    for (let i = 0; i < p.rooms; i++) {
      const [gx, gz] = cells[i], cx = p.x + gx * 32 + (rng() - 0.5) * 6, cz = p.z + gz * 32 + (rng() - 0.5) * 6;
      const w = 10 + rng() * 6, d = 9 + rng() * 5, h = 3.6 + rng();
      room(cx, cz, w, d, h, palette[Math.floor(rng() * palette.length)]);
      for (let k = 0; k < 1 + p.tier; k++) { const l = rollLoot(p.tier); W.spawnLoot(l.id, cx + (rng() - 0.5) * (w - 3), cz + (rng() - 0.5) * (d - 3), l.amount); }
    }
    for (let i = 0; i < 5 + p.tier * 2; i++) {
      const a = rng() * Math.PI * 2, dd = 10 + rng() * p.r * 0.8, x = p.x + Math.cos(a) * dd, z = p.z + Math.sin(a) * dd;
      crate(x, z); if (rng() < 0.5) { const l = rollLoot(p.tier); W.spawnLoot(l.id, x + 1.4, z, l.amount); }
    }
    for (let i = 0; i < p.tier; i++) { // container stacks
      const a = rng() * Math.PI * 2, dd = 20 + rng() * 50, x = p.x + Math.cos(a) * dd, z = p.z + Math.sin(a) * dd, by = heightAt(x, z);
      sbox(x, by, z, 6, 2.6, 2.4, [0xb5523b, 0x3b6fb5, 0x4f8f4f][i % 3]); if (i === 2) sbox(x, by + 2.6, z, 6, 2.6, 2.4, 0xd0a030);
    }
    if (p.name.includes('Docks')) sbox(p.x, -0.5, p.z - 105, 14, 0.9, 80, 0x6b4a2b); // pier over water
    W.jeepSpawns.push({ x: p.x + p.r + 8, z: p.z });
  });
  if (geos.length) {
    const merged = mergeGeometries(geos, false);
    scene.add(new THREE.Mesh(merged, new THREE.MeshLambertMaterial({ vertexColors: true })));
  }

  // scattered open-world loot + trees
  const rng = mulberry(4242);
  for (let i = 0; i < 70; i++) {
    const a = rng() * Math.PI * 2, d = Math.sqrt(rng()) * 820, x = Math.cos(a) * d, z = Math.sin(a) * d;
    if (heightAt(x, z) < 0.8) continue; const l = rollLoot(1); W.spawnLoot(l.id, x, z, l.amount);
  }
  const N = 450, trees = new THREE.InstancedMesh(new THREE.ConeGeometry(2, 7, 6), new THREE.MeshLambertMaterial({ color: 0x2f6b34 }), N), dummy = new THREE.Object3D();
  let n = 0;
  for (let tries = 0; tries < 3000 && n < N; tries++) {
    const a = rng() * Math.PI * 2, d = Math.sqrt(rng()) * 900, x = Math.cos(a) * d, z = Math.sin(a) * d, h = heightAt(x, z);
    if (h < 1) continue; if (POIS.some((p) => Math.hypot(x - p.x, z - p.z) < p.r * 1.2)) continue;
    dummy.position.set(x, h + 3.5, z); dummy.scale.setScalar(0.7 + rng() * 0.8); dummy.updateMatrix(); trees.setMatrixAt(n++, dummy.matrix);
  }
  trees.count = n; scene.add(trees);
  return W;
}
