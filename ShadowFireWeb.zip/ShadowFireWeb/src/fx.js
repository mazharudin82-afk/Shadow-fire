import * as THREE from 'three';
export function makeFx(G) {
  const pool = [], geo = new THREE.BoxGeometry(1, 1, 1), mat = new THREE.MeshBasicMaterial({ color: 0xffe08a });
  for (let i = 0; i < 24; i++) { const m = new THREE.Mesh(geo, mat); m.visible = false; G.scene.add(m); pool.push({ m, ttl: 0 }); }
  let idx = 0;
  return {
    tracer(a, b) {
      const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z, len = Math.hypot(dx, dy, dz);
      if (len < 1) return;
      const t = pool[idx++ % pool.length];
      t.m.position.set((a.x + b.x) / 2, (a.y + b.y) / 2, (a.z + b.z) / 2);
      t.m.scale.set(0.03, 0.03, len); t.m.lookAt(b.x, b.y, b.z); t.m.visible = true; t.ttl = 0.06;
    },
    update(dt) { for (const t of pool) if (t.ttl > 0) { t.ttl -= dt; if (t.ttl <= 0) t.m.visible = false; } },
  };
}
