// Headless logic test: runs a full 50-actor match without rendering.
import * as THREE from 'three';
import { createGame, startMatch, stepGame, syncVisuals } from '../src/game.js';
import { hitscan } from '../src/combat.js';
import { raySeg, dirFrom } from '../src/util.js';
import { toDegrees, S } from '../src/settings.js';

const fail = (m) => { console.error('FAIL:', m); process.exit(1); };
// --- math unit tests ---
const r = raySeg({ x: 0, y: 0, z: 0 }, { x: 0, y: 0, z: 1 }, { x: 0.3, y: -1, z: 10 }, { x: 0.3, y: 1, z: 10 });
if (Math.abs(r.d - 0.3) > 1e-6 || Math.abs(r.s - 10) > 1e-6) fail('raySeg ' + JSON.stringify(r));
const f = dirFrom(0, 0); if (Math.abs(f.z + 1) > 1e-9) fail('dirFrom');
const dg = toDegrees({ x: 100, y: 0 }, 0.016, 'hip', 1); if (!(dg.x > 0)) fail('toDegrees');

const scene = new THREE.Scene();
const events = { ended: null, shots: 0 };
const G = createGame(scene, { end: (r) => { events.ended = r; } });
startMatch(G, { squad: true, mates: [true, true, true], name: 'Tester' });
if (G.actors.length !== 50) fail('actor count ' + G.actors.length);
console.log('world loot items:', G.world.loots.length, ' vehicles:', G.vehicles.length);

const I = G.input, dt = 1 / 30; let steps = 0, maxMs = 0;
const t0 = Date.now();
while (!G.ended && G.time < 1500) {
  I.move.y = 1; I.move.x = Math.sin(G.time * 0.3) * 0.5; I.lookPx.x = Math.sin(G.time) * 6; I.lookPx.y = Math.cos(G.time * 0.7) * 3;
  I.fire = Math.floor(G.time) % 3 === 0;
  if (steps % 40 === 0) I.pulse.jump = true;
  if (steps % 97 === 0) I.pulse.reload = true;
  if (steps % 211 === 0) I.pulse.skill = true;
  if (steps % 150 === 0) I.pulse.cover = true;
  if (steps % 301 === 0) I.pulse.heal = true;
  if (steps % 500 === 0) I.pulse.ads = true;
  if (steps % 700 === 0) I.pulse.crouch = true;
  const s = Date.now(); stepGame(G, dt); syncVisuals(G); maxMs = Math.max(maxMs, Date.now() - s); steps++;
  if (steps % 600 === 0) for (const a of G.actors) if (!Number.isFinite(a.x + a.y + a.z)) fail('NaN actor ' + a.name);
}
for (const a of G.actors) if (!Number.isFinite(a.x + a.y + a.z + a.hp)) fail('NaN at end ' + a.name);
const kills = G.actors.reduce((s, a) => s + a.kills, 0);
console.log(JSON.stringify({ simSeconds: Math.round(G.time), alive: G.alive, zonePhase: G.zone.idx, zoneR: Math.round(G.zone.r), totalKills: kills, ended: events.ended, wallMs: Date.now() - t0, maxStepMs: maxMs }));
if (!G.ended) fail('match did not end in 1500 sim-seconds');
console.log('SIM OK');
