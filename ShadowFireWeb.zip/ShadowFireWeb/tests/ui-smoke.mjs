// Smoke test of UI + input binding with a fake permissive DOM (catches reference/typo errors).
const all = [];
const noop = () => {};
function fakeEl(tag) {
  const t = { tag, children: [], style: { setProperty: noop }, dataset: {}, classList: { add: noop, remove: noop, toggle: noop, contains: () => false }, _h: '' };
  const p = new Proxy(t, {
    get(o, k) {
      if (k === 'innerHTML') return o._h; if (k === 'firstChild') return o.children[0] || fakeEl('x'); if (k === 'children') return o.children;
      if (k in o) return o[k];
      if (k === 'getBoundingClientRect') return () => ({ left: 0, top: 0, width: 100, height: 100 });
      if (k === 'getContext') return () => new Proxy({}, { get: () => noop, set: () => true });
      if (typeof k === 'symbol') return undefined;
      return noop;
    },
    set(o, k, v) {
      if (k === 'innerHTML') {
        o._h = v; o.children = []; let depth = 0;       // create one fake child per top-level <div>
        for (const m of String(v).matchAll(/<div|<\/div>/g)) { if (m[0] === '<div') { if (depth === 0) o.children.push(fakeEl('div')); depth++; } else depth--; }
      } else o[k] = v;
      return true;
    },
  });
  t.appendChild = (c) => { t.children.push(c); return c; };
  t.remove = noop; all.push(p); return p;
}
const store = {};
globalThis.localStorage = { getItem: (k) => store[k] || null, setItem: (k, v) => { store[k] = v; } };
globalThis.document = { createElement: fakeEl, body: fakeEl('body'), documentElement: fakeEl('html'), pointerLockElement: null };
globalThis.window = { addEventListener: noop, innerWidth: 1280, innerHeight: 720, devicePixelRatio: 1 };
globalThis.location = { reload: noop };
globalThis.screen = {};

const THREE = await import('three');
const { createGame, startMatch, stepGame, syncVisuals } = await import('../src/game.js');
const { buildUI, installErrorOverlay } = await import('../src/ui.js');
const { bindInput } = await import('../src/input.js');
const { S } = await import('../src/settings.js');

installErrorOverlay();
const app = fakeEl('div');
let ui = null;
const G = createGame(new THREE.Scene(), { hitmarker: (h) => ui.hitmarker(h), hurt: () => ui.hurt(), toast: (s) => ui.toast(s), end: (r) => ui.showResult(r) });
ui = buildUI(app, G, { onStart: (cfg) => startMatch(G, cfg), onQuality: noop });
bindInput(G.input, { ...ui.els, buttons: [], canvas: fakeEl('canvas') }, S);

// press every lobby/hud button handler once (settings open/close included)
for (const e of all.slice()) if (typeof e.onclick === 'function' && e.className !== 'btn go') { try { e.onclick({ target: e }); } catch (err) { console.error('onclick failed', e.className, err); process.exit(1); } }
const start = all.find((e) => e.className === 'btn go' && e.onclick); start.onclick();
if (!G.started) { console.error('match did not start from UI'); process.exit(1); }
for (let i = 0; i < 900; i++) {
  G.input.fire = i % 20 < 10; G.input.move.y = 1; G.input.lookPx.x = 5;
  if (i % 100 === 0) G.input.pulse.use = true;
  stepGame(G, 1 / 30); syncVisuals(G); ui.update(G, 1 / 30);
}
// settings sliders
for (const e of all) if (typeof e.oninput === 'function') { e.value = '1.5'; e.oninput(); }
ui.showResult({ win: true, place: 1, kills: 3, time: 500 });
console.log('UI SMOKE OK; elements created:', all.length, 'player hp', Math.round(G.player.hp), 'alive', G.alive);
